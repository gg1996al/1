import { PrismaClient } from '@prisma/client';

// Единственный экземпляр PrismaClient на весь процесс (best practice для Node + Prisma),
// иначе при hot-reload в dev-режиме плодятся лишние соединения с БД.
const globalForPrisma = globalThis;

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}
