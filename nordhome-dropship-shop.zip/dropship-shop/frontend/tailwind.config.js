/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#F4F6F1',
        ink: '#1C231E',
        surface: '#FFFFFF',
        line: '#DDE3D8',
        muted: '#6B7568',
        primary: {
          DEFAULT: '#2F5D46',
          dark: '#1F3F30',
          light: '#E7EEE7',
        },
        accent: {
          DEFAULT: '#C89B3C',
          dark: '#9C7A2C',
          light: '#F6EAC9',
        },
        danger: '#B3462C',
      },
      fontFamily: {
        display: ['"Fraunces"', 'ui-serif', 'Georgia', 'serif'],
        sans: ['"Inter"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
      },
      borderRadius: {
        sm: '4px',
        md: '8px',
        lg: '14px',
      },
      boxShadow: {
        card: '0 1px 2px rgba(28,35,30,0.04), 0 8px 24px -12px rgba(28,35,30,0.12)',
      },
    },
  },
  plugins: [],
};
