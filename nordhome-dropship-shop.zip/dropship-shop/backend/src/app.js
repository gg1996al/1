import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';

import authRoutes from './routes/authRoutes.js';
import productRoutes from './routes/productRoutes.js';
import cartRoutes from './routes/cartRoutes.js';
import orderRoutes from './routes/orderRoutes.js';
import paymentRoutes from './routes/paymentRoutes.js';
import adminRoutes from './routes/adminRoutes.js';
import { stripeWebhook } from './controllers/paymentController.js';
import { notFoundHandler, errorHandler } from './middleware/errorHandler.js';

export function createApp() {
  const app = express();

  app.set('trust proxy', 1);
  app.use(helmet());
  app.use(
    cors({
      origin: process.env.CLIENT_URL || 'http://localhost:5173',
      credentials: true,
    })
  );
  app.use(compression());
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

  // ВАЖНО: Stripe webhook требует "сырое" тело запроса для проверки подписи,
  // поэтому монтируется ДО express.json() и не проходит через общий JSON-парсер.
  app.post('/api/payments/webhook', express.raw({ type: 'application/json' }), stripeWebhook);

  app.use(express.json({ limit: '2mb' }));
  app.use(cookieParser());

  // Общий rate-limit на весь API, отдельный — жёстче — на аутентификацию (защита от брутфорса).
  app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, max: 500 }));
  app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, max: 20 }));
  app.use('/api/auth/register', rateLimit({ windowMs: 60 * 60 * 1000, max: 10 }));

  app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'nordhome-backend' }));

  app.use('/api/auth', authRoutes);
  app.use('/api/products', productRoutes);
  app.use('/api/cart', cartRoutes);
  app.use('/api/orders', orderRoutes);
  app.use('/api/payments', paymentRoutes);
  app.use('/api/admin', adminRoutes);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
