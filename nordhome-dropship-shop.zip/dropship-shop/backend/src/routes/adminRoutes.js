import { Router } from 'express';
import { body } from 'express-validator';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import {
  getDashboardStats,
  adminListProducts, adminCreateProduct, adminUpdateProduct, adminDeleteProduct,
  adminCreateCategory,
  adminListOrders, adminUpdateOrderStatus,
  adminListUsers,
} from '../controllers/adminController.js';
import { listSuppliers, createSupplier, importCatalog } from '../controllers/supplierController.js';

const router = Router();
router.use(requireAuth, requireRole('ADMIN'));

router.get('/dashboard', getDashboardStats);

router.get('/products', adminListProducts);
router.post(
  '/products',
  [
    body('title').notEmpty(), body('description').notEmpty(),
    body('price').isFloat({ min: 0 }), body('costPrice').isFloat({ min: 0 }),
    body('sku').notEmpty(), body('categoryId').notEmpty(),
  ],
  validate,
  adminCreateProduct
);
router.patch('/products/:id', adminUpdateProduct);
router.delete('/products/:id', adminDeleteProduct);

router.post('/categories', [body('name').notEmpty()], validate, adminCreateCategory);

router.get('/orders', adminListOrders);
router.patch('/orders/:id/status', [body('status').notEmpty()], validate, adminUpdateOrderStatus);

router.get('/users', adminListUsers);

router.get('/suppliers', listSuppliers);
router.post('/suppliers', [body('name').notEmpty()], validate, createSupplier);
router.post('/suppliers/:id/import', importCatalog);

export default router;
