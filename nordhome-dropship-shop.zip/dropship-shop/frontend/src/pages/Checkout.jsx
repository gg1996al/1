import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, getErrorMessage } from '../api/client.js';
import { useCartStore } from '../store/cartStore.js';

export default function Checkout() {
  const { items, subtotal, reset } = useCartStore();
  const navigate = useNavigate();

  const [address, setAddress] = useState({
    fullName: '', phone: '', country: 'UA', city: '', street: '', postalCode: '',
  });
  const [status, setStatus] = useState('idle');
  const [error, setError] = useState('');

  const shipping = subtotal >= 60 ? 0 : 4.99;

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus('loading');
    setError('');
    try {
      const { data } = await api.post('/orders', { shippingAddress: address });
      reset();

      try {
        const session = await api.post('/payments/create-checkout-session', { orderId: data.order.id });
        window.location.href = session.data.url;
      } catch {
        // Stripe не настроен в этом окружении (demo) — не блокируем показ успешного оформления заказа.
        navigate(`/order-success?orderId=${data.order.id}&demo=1`);
      }
    } catch (err) {
      setStatus('idle');
      setError(getErrorMessage(err));
    }
  }

  if (items.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-24 text-center">
        <p className="text-muted">Корзина пуста.</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
      <h1 className="font-display text-3xl mb-8">Оформление заказа</h1>

      <div className="grid md:grid-cols-[1fr_300px] gap-10">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="eyebrow mb-1">Адрес доставки</div>
          <input required placeholder="Полное имя" value={address.fullName}
            onChange={(e) => setAddress({ ...address, fullName: e.target.value })} className="input-field" />
          <input required placeholder="Телефон" value={address.phone}
            onChange={(e) => setAddress({ ...address, phone: e.target.value })} className="input-field" />
          <div className="grid grid-cols-2 gap-3">
            <input required placeholder="Город" value={address.city}
              onChange={(e) => setAddress({ ...address, city: e.target.value })} className="input-field" />
            <input required placeholder="Почтовый индекс" value={address.postalCode}
              onChange={(e) => setAddress({ ...address, postalCode: e.target.value })} className="input-field" />
          </div>
          <input required placeholder="Улица, дом, квартира" value={address.street}
            onChange={(e) => setAddress({ ...address, street: e.target.value })} className="input-field" />

          {error && <p className="text-danger text-sm">{error}</p>}

          <button className="btn-primary w-full" disabled={status === 'loading'}>
            {status === 'loading' ? 'Обрабатываем…' : 'Перейти к оплате'}
          </button>
          <p className="text-xs text-muted">
            После оплаты заказ автоматически передаётся поставщику на отправку.
          </p>
        </form>

        <div className="card p-6 h-fit">
          <h2 className="font-display text-lg mb-4">Ваш заказ</h2>
          <ul className="space-y-3 mb-4">
            {items.map((item) => (
              <li key={item.id} className="flex justify-between text-sm">
                <span className="text-muted line-clamp-1 pr-2">{item.product.title} × {item.quantity}</span>
                <span className="font-mono shrink-0">${(item.product.price * item.quantity).toFixed(2)}</span>
              </li>
            ))}
          </ul>
          <div className="space-y-2 text-sm border-t border-line pt-4">
            <div className="flex justify-between"><span className="text-muted">Товары</span><span className="font-mono">${subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between"><span className="text-muted">Доставка</span><span className="font-mono">{shipping === 0 ? 'Бесплатно' : `$${shipping.toFixed(2)}`}</span></div>
            <div className="flex justify-between font-medium pt-2 border-t border-line"><span>Итого</span><span className="font-mono text-lg">${(subtotal + shipping).toFixed(2)}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}
