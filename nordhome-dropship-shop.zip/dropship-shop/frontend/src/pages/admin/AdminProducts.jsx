import { useEffect, useState } from 'react';
import { api, getErrorMessage } from '../../api/client.js';

const EMPTY_FORM = {
  title: '', description: '', price: '', compareAtPrice: '', costPrice: '',
  sku: '', stock: '', categoryId: '', images: '', supplierId: '',
};

export default function AdminProducts() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');

  async function load() {
    const [p, c, s] = await Promise.all([
      api.get('/admin/products', { params: { search } }),
      api.get('/products/categories'),
      api.get('/admin/suppliers'),
    ]);
    setProducts(p.data.items);
    setCategories(c.data.categories);
    setSuppliers(s.data.suppliers);
  }

  useEffect(() => { load(); }, [search]);

  function startCreate() {
    setForm(EMPTY_FORM);
    setEditingId(null);
    setShowForm(true);
    setError('');
  }

  function startEdit(p) {
    setForm({
      title: p.title, description: p.description, price: p.price, compareAtPrice: p.compareAtPrice || '',
      costPrice: p.costPrice, sku: p.sku, stock: p.stock, categoryId: p.category?.id || '',
      images: (p.images || []).join(', '), supplierId: p.supplierId || '',
    });
    setEditingId(p.id);
    setShowForm(true);
    setError('');
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    const payload = {
      title: form.title,
      description: form.description,
      price: Number(form.price),
      compareAtPrice: form.compareAtPrice ? Number(form.compareAtPrice) : null,
      costPrice: Number(form.costPrice),
      sku: form.sku,
      stock: Number(form.stock),
      categoryId: form.categoryId,
      supplierId: form.supplierId || null,
      images: form.images.split(',').map((s) => s.trim()).filter(Boolean),
    };
    try {
      if (editingId) {
        await api.patch(`/admin/products/${editingId}`, payload);
      } else {
        await api.post('/admin/products', payload);
      }
      setShowForm(false);
      load();
    } catch (err) {
      setError(getErrorMessage(err));
    }
  }

  async function handleDeactivate(id) {
    if (!confirm('Скрыть товар из каталога?')) return;
    await api.delete(`/admin/products/${id}`);
    load();
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6 gap-4">
        <input
          placeholder="Поиск по названию или SKU…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="input-field max-w-xs"
        />
        <button onClick={startCreate} className="btn-primary shrink-0">+ Добавить товар</button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card p-6 mb-8 space-y-3">
          <h3 className="font-display text-lg mb-2">{editingId ? 'Редактировать товар' : 'Новый товар'}</h3>
          <input required placeholder="Название" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="input-field" />
          <textarea required placeholder="Описание" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="input-field min-h-[80px]" />
          <div className="grid grid-cols-3 gap-3">
            <input required type="number" step="0.01" placeholder="Цена, $" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="input-field" />
            <input type="number" step="0.01" placeholder="Старая цена (опц.)" value={form.compareAtPrice} onChange={(e) => setForm({ ...form, compareAtPrice: e.target.value })} className="input-field" />
            <input required type="number" step="0.01" placeholder="Себестоимость, $" value={form.costPrice} onChange={(e) => setForm({ ...form, costPrice: e.target.value })} className="input-field" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <input required placeholder="SKU" value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} className="input-field" />
            <input required type="number" placeholder="Остаток на складе" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} className="input-field" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <select required value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })} className="input-field">
              <option value="">Категория…</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <select value={form.supplierId} onChange={(e) => setForm({ ...form, supplierId: e.target.value })} className="input-field">
              <option value="">Без привязки к поставщику</option>
              {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <input placeholder="URL картинок через запятую" value={form.images} onChange={(e) => setForm({ ...form, images: e.target.value })} className="input-field" />

          {error && <p className="text-danger text-sm">{error}</p>}

          <div className="flex gap-3 pt-2">
            <button className="btn-primary">{editingId ? 'Сохранить' : 'Создать'}</button>
            <button type="button" onClick={() => setShowForm(false)} className="btn-secondary">Отмена</button>
          </div>
        </form>
      )}

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-line text-left text-muted">
              <th className="p-3 font-medium">Товар</th>
              <th className="p-3 font-medium">Цена</th>
              <th className="p-3 font-medium">Маржа</th>
              <th className="p-3 font-medium">Остаток</th>
              <th className="p-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} className="border-b border-line last:border-0">
                <td className="p-3">
                  <div className="font-medium line-clamp-1">{p.title}</div>
                  <div className="text-xs text-muted font-mono">{p.sku}</div>
                </td>
                <td className="p-3 font-mono">${p.price.toFixed(2)}</td>
                <td className="p-3 font-mono text-primary">${p.margin?.toFixed(2)} ({p.marginPercent}%)</td>
                <td className="p-3 font-mono">{p.stock}</td>
                <td className="p-3 text-right space-x-3">
                  <button onClick={() => startEdit(p)} className="btn-ghost">Изменить</button>
                  <button onClick={() => handleDeactivate(p.id)} className="text-danger text-sm hover:underline">Скрыть</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
