import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../store/authStore.js';
import { getErrorMessage } from '../api/client.js';

export default function Login() {
  const { login } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [status, setStatus] = useState('idle');

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus('loading');
    setError('');
    try {
      await login(form.email, form.password);
      navigate(location.state?.from || '/');
    } catch (err) {
      setStatus('idle');
      setError(getErrorMessage(err));
    }
  }

  return (
    <div className="max-w-sm mx-auto px-4 py-20">
      <h1 className="font-display text-3xl mb-2">С возвращением</h1>
      <p className="text-muted text-sm mb-8">Войдите, чтобы продолжить покупки.</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <input required type="email" placeholder="Email" value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })} className="input-field" />
        <input required type="password" placeholder="Пароль" value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })} className="input-field" />
        {error && <p className="text-danger text-sm">{error}</p>}
        <button className="btn-primary w-full" disabled={status === 'loading'}>
          {status === 'loading' ? 'Входим…' : 'Войти'}
        </button>
      </form>

      <p className="text-sm text-muted mt-6">
        Нет аккаунта? <Link to="/register" className="text-primary font-medium hover:underline">Зарегистрироваться</Link>
      </p>
      <p className="text-xs text-muted mt-8 border-t border-line pt-4">
        Демо-админ: admin@nordhome.shop / Admin12345! (после запуска <code className="font-mono">npm run seed</code>)
      </p>
    </div>
  );
}
