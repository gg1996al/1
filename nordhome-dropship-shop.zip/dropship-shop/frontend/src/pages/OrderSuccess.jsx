import { Link, useSearchParams } from 'react-router-dom';

export default function OrderSuccess() {
  const [params] = useSearchParams();
  const isDemo = params.get('demo') === '1';

  return (
    <div className="max-w-lg mx-auto px-4 py-24 text-center">
      <div className="w-14 h-14 rounded-full bg-primary-light text-primary flex items-center justify-center mx-auto mb-6">
        <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
      <h1 className="font-display text-3xl mb-3">Заказ оформлен!</h1>
      <p className="text-muted mb-8">
        {isDemo
          ? 'Оплата в этом демо-окружении не настроена (нет ключей Stripe), но заказ успешно создан и виден в личном кабинете и в админ-панели.'
          : 'Мы передали заказ поставщику на отправку. Следить за статусом можно в личном кабинете.'}
      </p>
      <div className="flex items-center justify-center gap-4">
        <Link to="/account" className="btn-primary">Мои заказы</Link>
        <Link to="/catalog" className="btn-ghost">Продолжить покупки →</Link>
      </div>
    </div>
  );
}
