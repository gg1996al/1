import { prisma } from '../config/db.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { ApiError } from '../utils/ApiError.js';
import { serializeProduct } from '../utils/serializers.js';

// GET /api/products?search=&category=&minPrice=&maxPrice=&sort=&page=&limit=
export const listProducts = asyncHandler(async (req, res) => {
  const {
    search, category, minPrice, maxPrice,
    sort = 'newest', page = '1', limit = '12',
  } = req.query;

  const where = { isActive: true };

  if (search) {
    where.OR = [
      { title: { contains: search } },
      { description: { contains: search } },
    ];
  }
  if (category) where.category = { slug: category };
  if (minPrice || maxPrice) {
    where.price = {};
    if (minPrice) where.price.gte = Number(minPrice);
    if (maxPrice) where.price.lte = Number(maxPrice);
  }

  const orderBy = {
    newest: { createdAt: 'desc' },
    price_asc: { price: 'asc' },
    price_desc: { price: 'desc' },
    rating: { rating: 'desc' },
  }[sort] || { createdAt: 'desc' };

  const take = Math.min(Number(limit) || 12, 48);
  const skip = (Math.max(Number(page) || 1, 1) - 1) * take;

  const [items, total] = await Promise.all([
    prisma.product.findMany({ where, orderBy, take, skip, include: { category: true } }),
    prisma.product.count({ where }),
  ]);

  res.json({
    items: items.map((p) => serializeProduct(p)),
    total,
    page: Number(page) || 1,
    pageSize: take,
    totalPages: Math.ceil(total / take),
  });
});

export const getProductBySlug = asyncHandler(async (req, res) => {
  const product = await prisma.product.findUnique({
    where: { slug: req.params.slug },
    include: {
      category: true,
      reviews: { include: { user: { select: { name: true } } }, orderBy: { createdAt: 'desc' } },
    },
  });
  if (!product || !product.isActive) throw ApiError.notFound('Товар не найден');
  res.json({ product: serializeProduct(product) });
});

export const listCategories = asyncHandler(async (req, res) => {
  const categories = await prisma.category.findMany({
    include: { _count: { select: { products: true } } },
    orderBy: { name: 'asc' },
  });
  res.json({ categories });
});

// POST /api/products/:slug/reviews  (авторизованный пользователь)
export const addReview = asyncHandler(async (req, res) => {
  const { rating, comment } = req.body;
  const product = await prisma.product.findUnique({ where: { slug: req.params.slug } });
  if (!product) throw ApiError.notFound('Товар не найден');

  const review = await prisma.review.upsert({
    where: { productId_userId: { productId: product.id, userId: req.user.id } },
    update: { rating, comment },
    create: { productId: product.id, userId: req.user.id, rating, comment },
  });

  const agg = await prisma.review.aggregate({
    where: { productId: product.id },
    _avg: { rating: true },
    _count: true,
  });
  await prisma.product.update({
    where: { id: product.id },
    data: { rating: agg._avg.rating || 0, reviewsCount: agg._count },
  });

  res.status(201).json({ review });
});
