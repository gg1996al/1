import { prisma } from '../config/db.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { ApiError } from '../utils/ApiError.js';
import { serializeProduct } from '../utils/serializers.js';

async function getCartPayload(userId) {
  const items = await prisma.cartItem.findMany({
    where: { userId },
    include: { product: { include: { category: true } } },
    orderBy: { createdAt: 'asc' },
  });

  const serialized = items
    .filter((i) => i.product.isActive)
    .map((i) => ({
      id: i.id,
      quantity: i.quantity,
      product: serializeProduct(i.product),
    }));

  const subtotal = serialized.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  return { items: serialized, subtotal: Number(subtotal.toFixed(2)), itemCount: serialized.reduce((n, i) => n + i.quantity, 0) };
}

export const getCart = asyncHandler(async (req, res) => {
  res.json(await getCartPayload(req.user.id));
});

export const addToCart = asyncHandler(async (req, res) => {
  const { productId, quantity = 1 } = req.body;

  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product || !product.isActive) throw ApiError.notFound('Товар не найден');
  if (product.stock < quantity) throw ApiError.badRequest('Недостаточно товара на складе поставщика');

  await prisma.cartItem.upsert({
    where: { userId_productId: { userId: req.user.id, productId } },
    update: { quantity: { increment: quantity } },
    create: { userId: req.user.id, productId, quantity },
  });

  res.status(201).json(await getCartPayload(req.user.id));
});

export const updateCartItem = asyncHandler(async (req, res) => {
  const { quantity } = req.body;
  const item = await prisma.cartItem.findUnique({ where: { id: req.params.itemId } });
  if (!item || item.userId !== req.user.id) throw ApiError.notFound('Позиция корзины не найдена');

  if (quantity <= 0) {
    await prisma.cartItem.delete({ where: { id: item.id } });
  } else {
    await prisma.cartItem.update({ where: { id: item.id }, data: { quantity } });
  }
  res.json(await getCartPayload(req.user.id));
});

export const removeCartItem = asyncHandler(async (req, res) => {
  const item = await prisma.cartItem.findUnique({ where: { id: req.params.itemId } });
  if (!item || item.userId !== req.user.id) throw ApiError.notFound('Позиция корзины не найдена');
  await prisma.cartItem.delete({ where: { id: item.id } });
  res.json(await getCartPayload(req.user.id));
});

export const clearCart = asyncHandler(async (req, res) => {
  await prisma.cartItem.deleteMany({ where: { userId: req.user.id } });
  res.json(await getCartPayload(req.user.id));
});
