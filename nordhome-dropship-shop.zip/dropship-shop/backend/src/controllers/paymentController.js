import { prisma } from '../config/db.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { ApiError } from '../utils/ApiError.js';
import { createCheckoutSession, constructWebhookEvent } from '../services/stripeService.js';
import { fulfillOrder } from '../services/fulfillmentService.js';

export const createSession = asyncHandler(async (req, res) => {
  const { orderId } = req.body;
  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } });
  if (!order || order.userId !== req.user.id) throw ApiError.notFound('Заказ не найден');
  if (order.status !== 'PENDING') throw ApiError.badRequest('Заказ уже оплачен или обрабатывается');

  const clientUrl = process.env.CLIENT_URL || 'http://localhost:5173';
  const session = await createCheckoutSession({
    order,
    customerEmail: req.user.email,
    successUrl: `${clientUrl}/order-success?orderId=${order.id}`,
    cancelUrl: `${clientUrl}/checkout?cancelled=1`,
  });

  await prisma.order.update({
    where: { id: order.id },
    data: { paymentProvider: 'stripe', paymentIntentId: session.id },
  });

  res.json({ url: session.url });
});

// Webhook требует raw body — подключается ДО express.json() в app.js для этого конкретного маршрута.
export const stripeWebhook = asyncHandler(async (req, res) => {
  const signature = req.headers['stripe-signature'];
  let event;
  try {
    event = constructWebhookEvent(req.body, signature);
  } catch (err) {
    return res.status(400).send(`Webhook signature error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const orderId = session.metadata?.orderId;
    if (orderId) {
      const order = await prisma.order.update({
        where: { id: orderId },
        data: { status: 'PAID', paidAt: new Date() },
      });
      await fulfillOrder(order.id);
    }
  }

  res.json({ received: true });
});
