export default function Filters({ categories, filters, onChange }) {
  return (
    <aside className="space-y-8">
      <div>
        <div className="eyebrow mb-3">Категория</div>
        <ul className="space-y-1.5">
          <li>
            <button
              onClick={() => onChange({ category: '' })}
              className={`text-sm transition-colors ${!filters.category ? 'text-primary font-medium' : 'text-muted hover:text-ink'}`}
            >
              Все категории
            </button>
          </li>
          {categories.map((c) => (
            <li key={c.id}>
              <button
                onClick={() => onChange({ category: c.slug })}
                className={`text-sm transition-colors flex items-center justify-between w-full ${filters.category === c.slug ? 'text-primary font-medium' : 'text-muted hover:text-ink'}`}
              >
                <span>{c.name}</span>
                <span className="font-mono text-xs">{c._count?.products ?? ''}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <div className="eyebrow mb-3">Цена, $</div>
        <div className="flex items-center gap-2">
          <input
            type="number"
            placeholder="от"
            defaultValue={filters.minPrice}
            onBlur={(e) => onChange({ minPrice: e.target.value })}
            className="input-field !py-1.5 w-full"
          />
          <span className="text-muted">—</span>
          <input
            type="number"
            placeholder="до"
            defaultValue={filters.maxPrice}
            onBlur={(e) => onChange({ maxPrice: e.target.value })}
            className="input-field !py-1.5 w-full"
          />
        </div>
      </div>

      <div>
        <div className="eyebrow mb-3">Сортировка</div>
        <select
          value={filters.sort}
          onChange={(e) => onChange({ sort: e.target.value })}
          className="input-field !py-1.5"
        >
          <option value="newest">Сначала новые</option>
          <option value="price_asc">Сначала дешевле</option>
          <option value="price_desc">Сначала дороже</option>
          <option value="rating">По рейтингу</option>
        </select>
      </div>
    </aside>
  );
}
