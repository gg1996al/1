import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuthStore } from '../store/authStore.js';

const STATUS_LABELS = {
  PENDING: { label: 'Ожидает оплаты', color: 'text-muted' },
  PAID: { label: 'Оплачен', color: 'text-primary' },
  PROCESSING: { label: 'Передан поставщику', color: 'text-primary' },
  SHIPPED: { label: 'Отправлен', color: 'text-accent-dark' },
  DELIVERED: { label: 'Доставлен', color: 'text-primary' },
  CANCELLED: { label: 'Отменён', color: 'text-danger' },
  REFUNDED: { label: 'Возврат', color: 'text-danger' },
};

export default function Account() {
  const { user } = useAuthStore();
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    api.get('/orders').then((r) => setOrders(r.data.orders));
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
      <div className="mb-8">
        <div className="eyebrow mb-2">Личный кабинет</div>
        <h1 className="font-display text-3xl">{user.name}</h1>
        <p className="text-muted text-sm mt-1">{user.email}</p>
      </div>

      <h2 className="font-display text-xl mb-4">Мои заказы</h2>

      {orders.length === 0 ? (
        <div className="card p-8 text-center">
          <p className="text-muted mb-4">У вас пока нет заказов.</p>
          <Link to="/catalog" className="btn-primary">В каталог</Link>
        </div>
      ) : (
        <ul className="space-y-4">
          {orders.map((order) => {
            const st = STATUS_LABELS[order.status] || { label: order.status, color: 'text-muted' };
            return (
              <li key={order.id} className="card p-5">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <span className="font-mono text-sm font-medium">{order.orderNumber}</span>
                    <span className="text-xs text-muted ml-2">{new Date(order.createdAt).toLocaleDateString('ru-RU')}</span>
                  </div>
                  <span className={`text-sm font-medium ${st.color}`}>{st.label}</span>
                </div>
                <ul className="text-sm text-muted space-y-1 mb-3">
                  {order.items.map((i) => (
                    <li key={i.id}>{i.titleSnapshot} × {i.quantity}</li>
                  ))}
                </ul>
                <div className="flex justify-between items-center border-t border-line pt-3">
                  <span className="text-sm text-muted">Доставка: {order.shippingAddress?.city}</span>
                  <span className="font-mono font-medium">${order.total.toFixed(2)}</span>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
