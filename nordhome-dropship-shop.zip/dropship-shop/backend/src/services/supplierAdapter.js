/**
 * Слой интеграции с поставщиками.
 *
 * Модель дропшиппинга здесь — посредническая: магазин НЕ хранит физический склад,
 * а перепродаёт товары поставщика с наценкой (price - costPrice). После оплаты заказа
 * позиции нужно передать поставщику на фулфилмент. Разные поставщики (CJ Dropshipping,
 * AliExpress API, локальный опт по CSV-прайсу и т.д.) имеют разные протоколы — поэтому
 * используется паттерн "адаптер": единый интерфейс `SupplierAdapter`, за которым может
 * стоять любая реализация. Чтобы подключить нового поставщика в проде, достаточно
 * реализовать 3 метода ниже и зарегистрировать адаптер в getAdapter().
 */

import { parse } from 'csv-parse/sync';

/**
 * @typedef {Object} SupplierProductDTO
 * @property {string} externalId
 * @property {string} title
 * @property {string} description
 * @property {number} costPrice
 * @property {number} suggestedRetailPrice
 * @property {number} stock
 * @property {string[]} images
 * @property {string} sku
 * @property {Object} attributes
 */

class SupplierAdapter {
  /** @returns {Promise<SupplierProductDTO[]>} */
  async fetchCatalog(_config) {
    throw new Error('fetchCatalog() не реализован');
  }
  /** Отправить заказ поставщику на фулфилмент. @returns {Promise<{ok: boolean, supplierOrderRef?: string, error?: string}>} */
  async placeOrder(_config, _order) {
    throw new Error('placeOrder() не реализован');
  }
  /** Проверить актуальные остатки/цену по одному товару (для синка). */
  async checkAvailability(_config, _externalId) {
    throw new Error('checkAvailability() не реализован');
  }
}

/**
 * MOCK-адаптер — встроенный демо-поставщик. Позволяет разрабатывать и тестировать
 * весь цикл (импорт каталога → продажа → "передача на фулфилмент") без реального
 * контракта с поставщиком. Замените на реальный адаптер, когда появится API поставщика.
 */
class MockSupplierAdapter extends SupplierAdapter {
  async fetchCatalog() {
    return DEMO_CATALOG;
  }

  async placeOrder(_config, order) {
    // Имитация похода во внешний API поставщика.
    await new Promise((r) => setTimeout(r, 150));
    return { ok: true, supplierOrderRef: `MOCK-${order.id.slice(0, 8).toUpperCase()}` };
  }

  async checkAvailability(_config, externalId) {
    const item = DEMO_CATALOG.find((p) => p.externalId === externalId);
    if (!item) return { available: false };
    return { available: item.stock > 0, stock: item.stock, costPrice: item.costPrice };
  }
}

/**
 * CSV-адаптер — импорт прайса поставщика из CSV-файла (частый формат у оптовых
 * поставщиков дропшиппинга). Ожидаемые колонки:
 * external_id,title,description,cost_price,retail_price,stock,sku,images,attributes
 * (images — через "|", attributes — JSON-строка, оба поля опциональны)
 */
class CsvSupplierAdapter extends SupplierAdapter {
  async fetchCatalog(config) {
    if (!config.csvContent) {
      throw new Error('Для CSV-поставщика нужно передать csvContent при импорте');
    }
    const records = parse(config.csvContent, { columns: true, skip_empty_lines: true, trim: true });
    return records.map((r) => ({
      externalId: r.external_id || r.sku,
      title: r.title,
      description: r.description || '',
      costPrice: Number(r.cost_price) || 0,
      suggestedRetailPrice: Number(r.retail_price) || Number(r.cost_price) * 1.6,
      stock: Number(r.stock) || 0,
      images: r.images ? r.images.split('|').filter(Boolean) : [],
      sku: r.sku || r.external_id,
      attributes: safeJsonParse(r.attributes) || {},
    }));
  }

  async placeOrder() {
    // У CSV-поставщиков обычно нет API для заказа — заказ оформляется вручную/по почте.
    return { ok: false, error: 'CSV-поставщик не поддерживает автоматическое оформление заказа. Оформите вручную.' };
  }

  async checkAvailability() {
    return { available: true }; // остатки по CSV не синкаются в реальном времени
  }
}

function safeJsonParse(str) {
  try {
    return JSON.parse(str);
  } catch {
    return null;
  }
}

const adapters = {
  MOCK: new MockSupplierAdapter(),
  CSV: new CsvSupplierAdapter(),
  API: new MockSupplierAdapter(), // заглушка-пример: замените на реальный REST-адаптер (CJ/AliExpress)
};

export function getAdapter(type) {
  const adapter = adapters[type];
  if (!adapter) throw new Error(`Неизвестный тип поставщика: ${type}`);
  return adapter;
}

// Стандартная наценка посредника по умолчанию при автоимпорте (если retail не указан явно).
export const DEFAULT_MARKUP_MULTIPLIER = 1.7;

// Демо-каталог "виртуального" поставщика — свежий, актуальный ассортимент ниши
// "умные гаджеты и вещи для дома" для первого запуска магазина без реального контракта.
const DEMO_CATALOG = [
  {
    externalId: 'SUP-1001', sku: 'NH-LMP-001',
    title: 'Умная лампа с диммером и управлением через приложение',
    description: 'Светодиодная лампа E27, 16 млн цветов, голосовое управление, работает с Alexa/Google Home.',
    costPrice: 6.4, suggestedRetailPrice: 19.9, stock: 142,
    images: ['https://images.unsplash.com/photo-1550985616-10810253b84d?w=800'],
    attributes: { color: 'RGBW', power: '9W' },
  },
  {
    externalId: 'SUP-1002', sku: 'NH-DIF-002',
    title: 'Аромадиффузор-увлажнитель с подсветкой',
    description: 'Ультразвуковой увлажнитель 300 мл, 7 цветов подсветки, автоотключение, бесшумная работа.',
    costPrice: 8.1, suggestedRetailPrice: 24.9, stock: 87,
    images: ['https://images.unsplash.com/photo-1602928321679-560bb453f190?w=800'],
    attributes: { volume: '300ml' },
  },
  {
    externalId: 'SUP-1003', sku: 'NH-ORG-003',
    title: 'Модульный органайзер для кухонных ящиков',
    description: 'Бамбуковый раздвижной органайзер для приборов, регулируется по ширине ящика.',
    costPrice: 5.2, suggestedRetailPrice: 16.5, stock: 210,
    images: ['https://images.unsplash.com/photo-1584622781564-1d987f7333c1?w=800'],
    attributes: { material: 'бамбук' },
  },
  {
    externalId: 'SUP-1004', sku: 'NH-PLG-004',
    title: 'Wi-Fi розетка с таймером и учётом энергопотребления',
    description: 'Умная розетка 16A, приложение Tuya/Smart Life, таймер, статистика потребления.',
    costPrice: 4.3, suggestedRetailPrice: 14.9, stock: 300,
    images: ['https://images.unsplash.com/photo-1558002038-1055907df827?w=800'],
    attributes: { amperage: '16A' },
  },
  {
    externalId: 'SUP-1005', sku: 'NH-BLK-005',
    title: 'Плотные шторы блэкаут с креплением на люверсах',
    description: 'Комплект 2 шт., светонепроницаемая ткань, шумопоглощение, термоизоляция.',
    costPrice: 11.0, suggestedRetailPrice: 32.9, stock: 65,
    images: ['https://images.unsplash.com/photo-1513694203232-719a280e022f?w=800'],
    attributes: { size: '140x260см' },
  },
  {
    externalId: 'SUP-1006', sku: 'NH-KTC-006',
    title: 'Набор силиконовых кухонных лопаток premium',
    description: '5 предметов, термостойкий силикон до 220°C, деревянные рукояти, не царапают покрытие.',
    costPrice: 6.9, suggestedRetailPrice: 21.9, stock: 178,
    images: ['https://images.unsplash.com/photo-1590794056486-58c936774265?w=800'],
    attributes: { pieces: 5 },
  },
  {
    externalId: 'SUP-1007', sku: 'NH-MIR-007',
    title: 'Настольное зеркало с LED-подсветкой и регулировкой яркости',
    description: 'Косметическое зеркало 10x увеличение, сенсорное управление яркостью, USB-питание.',
    costPrice: 9.5, suggestedRetailPrice: 27.9, stock: 54,
    images: ['https://images.unsplash.com/photo-1595515106969-1ce29566ff1c?w=800'],
    attributes: { magnification: '10x' },
  },
  {
    externalId: 'SUP-1008', sku: 'NH-VAC-008',
    title: 'Компактный ручной пылесос для дома и авто',
    description: 'Беспроводной, мощность всасывания 6000Pa, время работы 30 минут, съёмный аккумулятор.',
    costPrice: 14.8, suggestedRetailPrice: 42.9, stock: 39,
    images: ['https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800'],
    attributes: { power: '6000Pa' },
  },
];
