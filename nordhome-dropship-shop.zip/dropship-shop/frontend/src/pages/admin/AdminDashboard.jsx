import { useEffect, useState } from 'react';
import { api } from '../../api/client.js';

export default function AdminDashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    api.get('/admin/dashboard').then((r) => setData(r.data));
  }, []);

  if (!data) return <p className="text-muted">Загрузка…</p>;
  const { stats, lowStock, recentOrders } = data;

  return (
    <div className="space-y-10">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Выручка" value={`$${stats.revenue.toFixed(2)}`} />
        <StatCard label="Маржа посредника" value={`$${stats.margin.toFixed(2)}`} sub={`${stats.marginPercent}% от выручки`} accent />
        <StatCard label="Товаров в каталоге" value={stats.productCount} />
        <StatCard label="Покупателей" value={stats.userCount} />
      </div>

      <div>
        <h2 className="font-display text-xl mb-4">Мало на складе</h2>
        {lowStock.length === 0 ? (
          <p className="text-muted text-sm">Всё в достатке.</p>
        ) : (
          <ul className="card divide-y divide-line">
            {lowStock.map((p) => (
              <li key={p.id} className="p-4 flex items-center justify-between text-sm">
                <span>{p.title}</span>
                <span className="font-mono text-danger">{p.stock} шт.</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div>
        <h2 className="font-display text-xl mb-4">Последние заказы</h2>
        <ul className="card divide-y divide-line">
          {recentOrders.map((o) => (
            <li key={o.id} className="p-4 flex items-center justify-between text-sm">
              <div>
                <span className="font-mono font-medium">{o.orderNumber}</span>
                <span className="text-muted ml-2">{o.user?.name}</span>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-muted">{o.status}</span>
                <span className="font-mono font-medium">${o.total.toFixed(2)}</span>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function StatCard({ label, value, sub, accent }) {
  return (
    <div className="card p-5">
      <div className="text-xs text-muted mb-2">{label}</div>
      <div className={`font-display text-2xl ${accent ? 'text-primary' : ''}`}>{value}</div>
      {sub && <div className="text-xs text-muted mt-1">{sub}</div>}
    </div>
  );
}
