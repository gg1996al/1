import slugify from 'slugify';
import { prisma } from '../config/db.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { ApiError } from '../utils/ApiError.js';
import { serializeProduct, serializeOrder } from '../utils/serializers.js';

// -------------------- Dashboard --------------------

export const getDashboardStats = asyncHandler(async (req, res) => {
  const [productCount, orderCount, userCount, paidOrders] = await Promise.all([
    prisma.product.count(),
    prisma.order.count(),
    prisma.user.count({ where: { role: 'CUSTOMER' } }),
    prisma.order.findMany({
      where: { status: { in: ['PAID', 'PROCESSING', 'SHIPPED', 'DELIVERED'] } },
      include: { items: true },
    }),
  ]);

  const revenue = paidOrders.reduce((sum, o) => sum + o.total, 0);
  const margin = paidOrders.reduce(
    (sum, o) => sum + o.items.reduce((s, i) => s + (i.priceSnapshot - i.costSnapshot) * i.quantity, 0),
    0
  );

  const lowStock = await prisma.product.findMany({
    where: { isActive: true, stock: { lte: 10 } },
    orderBy: { stock: 'asc' },
    take: 5,
  });

  const recentOrders = await prisma.order.findMany({
    orderBy: { createdAt: 'desc' },
    take: 5,
    include: { items: true, user: { select: { name: true, email: true } } },
  });

  res.json({
    stats: {
      productCount,
      orderCount,
      userCount,
      revenue: Number(revenue.toFixed(2)),
      margin: Number(margin.toFixed(2)),
      marginPercent: revenue > 0 ? Number(((margin / revenue) * 100).toFixed(1)) : 0,
    },
    lowStock: lowStock.map((p) => serializeProduct(p, { includeCost: true })),
    recentOrders: recentOrders.map((o) => ({ ...serializeOrder(o), user: o.user })),
  });
});

// -------------------- Products --------------------

export const adminListProducts = asyncHandler(async (req, res) => {
  const { search, page = '1', limit = '20' } = req.query;
  const where = search
    ? { OR: [{ title: { contains: search } }, { sku: { contains: search } }] }
    : {};

  const take = Math.min(Number(limit) || 20, 100);
  const skip = (Math.max(Number(page) || 1, 1) - 1) * take;

  const [items, total] = await Promise.all([
    prisma.product.findMany({ where, include: { category: true, supplier: true }, orderBy: { createdAt: 'desc' }, take, skip }),
    prisma.product.count({ where }),
  ]);

  res.json({
    items: items.map((p) => serializeProduct(p, { includeCost: true })),
    total,
    page: Number(page) || 1,
    totalPages: Math.ceil(total / take),
  });
});

export const adminCreateProduct = asyncHandler(async (req, res) => {
  const { title, description, price, compareAtPrice, costPrice, sku, stock, categoryId, images, attributes, supplierId, supplierProductId } = req.body;

  const slug = await uniqueSlug(title);
  const product = await prisma.product.create({
    data: {
      title, description, price, compareAtPrice, costPrice, sku, stock: stock ?? 0,
      categoryId, supplierId, supplierProductId, slug,
      imagesJson: JSON.stringify(images || []),
      attributesJson: JSON.stringify(attributes || {}),
    },
  });
  res.status(201).json({ product: serializeProduct(product, { includeCost: true }) });
});

export const adminUpdateProduct = asyncHandler(async (req, res) => {
  const existing = await prisma.product.findUnique({ where: { id: req.params.id } });
  if (!existing) throw ApiError.notFound('Товар не найден');

  const { title, description, price, compareAtPrice, costPrice, sku, stock, categoryId, images, attributes, isActive, supplierId, supplierProductId } = req.body;

  const data = {};
  if (title !== undefined) { data.title = title; data.slug = await uniqueSlug(title, existing.id); }
  if (description !== undefined) data.description = description;
  if (price !== undefined) data.price = price;
  if (compareAtPrice !== undefined) data.compareAtPrice = compareAtPrice;
  if (costPrice !== undefined) data.costPrice = costPrice;
  if (sku !== undefined) data.sku = sku;
  if (stock !== undefined) data.stock = stock;
  if (categoryId !== undefined) data.categoryId = categoryId;
  if (isActive !== undefined) data.isActive = isActive;
  if (supplierId !== undefined) data.supplierId = supplierId;
  if (supplierProductId !== undefined) data.supplierProductId = supplierProductId;
  if (images !== undefined) data.imagesJson = JSON.stringify(images);
  if (attributes !== undefined) data.attributesJson = JSON.stringify(attributes);

  const product = await prisma.product.update({ where: { id: req.params.id }, data });
  res.json({ product: serializeProduct(product, { includeCost: true }) });
});

export const adminDeleteProduct = asyncHandler(async (req, res) => {
  await prisma.product.update({ where: { id: req.params.id }, data: { isActive: false } });
  res.status(204).send();
});

async function uniqueSlug(title, excludeId = null) {
  const base = slugify(title, { lower: true, strict: true, locale: 'ru' });
  let slug = base;
  let i = 1;
  while (await prisma.product.findFirst({ where: { slug, ...(excludeId ? { id: { not: excludeId } } : {}) } })) {
    slug = `${base}-${++i}`;
  }
  return slug;
}

// -------------------- Categories --------------------

export const adminCreateCategory = asyncHandler(async (req, res) => {
  const { name, description, image } = req.body;
  const slug = slugify(name, { lower: true, strict: true, locale: 'ru' });
  const category = await prisma.category.create({ data: { name, description, image, slug } });
  res.status(201).json({ category });
});

// -------------------- Orders --------------------

export const adminListOrders = asyncHandler(async (req, res) => {
  const { status, page = '1', limit = '20' } = req.query;
  const where = status ? { status } : {};
  const take = Math.min(Number(limit) || 20, 100);
  const skip = (Math.max(Number(page) || 1, 1) - 1) * take;

  const [items, total] = await Promise.all([
    prisma.order.findMany({
      where, include: { items: true, user: { select: { name: true, email: true } } },
      orderBy: { createdAt: 'desc' }, take, skip,
    }),
    prisma.order.count({ where }),
  ]);

  res.json({
    items: items.map((o) => ({ ...serializeOrder(o), user: o.user })),
    total, page: Number(page) || 1, totalPages: Math.ceil(total / take),
  });
});

export const adminUpdateOrderStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  const valid = ['PENDING', 'PAID', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED', 'REFUNDED'];
  if (!valid.includes(status)) throw ApiError.badRequest('Некорректный статус заказа');

  const order = await prisma.order.update({ where: { id: req.params.id }, data: { status } });
  res.json({ order: serializeOrder(order) });
});

// -------------------- Users --------------------

export const adminListUsers = asyncHandler(async (req, res) => {
  const users = await prisma.user.findMany({
    where: { role: 'CUSTOMER' },
    select: { id: true, email: true, name: true, phone: true, createdAt: true, _count: { select: { orders: true } } },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ users });
});
