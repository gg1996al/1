import axios from 'axios';

export const api = axios.create({
  baseURL: '/api',
  withCredentials: true, // отправляет httpOnly refresh-cookie
});

let accessToken = null;
export function setAccessToken(token) {
  accessToken = token;
}
export function getAccessToken() {
  return accessToken;
}

api.interceptors.request.use((config) => {
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`;
  }
  return config;
});

// При 401 пробуем один раз тихо обновить access-токен через refresh-cookie,
// чтобы пользователя не выкидывало из сессии при обычном истечении токена.
let refreshPromise = null;

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && !original._retry && !original.url.includes('/auth/')) {
      original._retry = true;
      try {
        refreshPromise = refreshPromise || api.post('/auth/refresh');
        const { data } = await refreshPromise;
        refreshPromise = null;
        setAccessToken(data.accessToken);
        original.headers.Authorization = `Bearer ${data.accessToken}`;
        return api(original);
      } catch (e) {
        refreshPromise = null;
        setAccessToken(null);
      }
    }
    return Promise.reject(error);
  }
);

export function getErrorMessage(err) {
  return err?.response?.data?.error || 'Что-то пошло не так. Попробуйте ещё раз.';
}
