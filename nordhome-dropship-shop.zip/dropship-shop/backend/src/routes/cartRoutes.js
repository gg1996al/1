import { Router } from 'express';
import { body } from 'express-validator';
import { getCart, addToCart, updateCartItem, removeCartItem, clearCart } from '../controllers/cartController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = Router();
router.use(requireAuth);

router.get('/', getCart);
router.post('/items', [body('productId').notEmpty(), body('quantity').optional().isInt({ min: 1 })], validate, addToCart);
router.patch('/items/:itemId', [body('quantity').isInt({ min: 0 })], validate, updateCartItem);
router.delete('/items/:itemId', removeCartItem);
router.delete('/', clearCart);

export default router;
