// Оборачивает async-контроллер, пробрасывая ошибки в errorHandler middleware,
// вместо повторения try/catch в каждом контроллере.
export const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);
