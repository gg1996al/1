import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client.js';
import ProductCard from '../components/ProductCard.jsx';

export default function Home() {
  const [featured, setFeatured] = useState([]);
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    api.get('/products', { params: { sort: 'rating', limit: 8 } }).then((r) => setFeatured(r.data.items));
    api.get('/products/categories').then((r) => setCategories(r.data.categories));
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-12 sm:pt-16 pb-20">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <div>
            <div className="eyebrow mb-4">Склад поставщика · отправка 24 часа</div>
            <h1 className="font-display text-5xl sm:text-6xl leading-[1.05] tracking-tight mb-6">
              Дом,<br />собранный<br /><span className="italic text-primary">со вкусом.</span>
            </h1>
            <p className="text-muted text-lg leading-relaxed mb-8 max-w-md">
              Умные гаджеты и вещи для дома напрямую от производителя — без складов
              и переплат посредников. Вы платите только за товар и доставку.
            </p>
            <div className="flex items-center gap-4">
              <Link to="/catalog" className="btn-primary">Смотреть каталог</Link>
              <Link to="/catalog?sort=newest" className="btn-ghost">Новинки →</Link>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-[4/5] rounded-lg overflow-hidden bg-primary-light">
              <img
                src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=900"
                alt="Уютный интерьер дома"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-5 -left-5 bg-surface border border-line rounded-md shadow-card px-4 py-3 hidden sm:block">
              <div className="price-tag pl-2 text-ink">
                <span className="text-lg font-semibold">$19.90</span>
                <span className="text-xs text-muted line-through">$29.90</span>
              </div>
              <div className="text-xs text-muted mt-0.5">Умная лампа RGBW</div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-20">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {categories.map((c) => (
            <Link
              key={c.id}
              to={`/catalog?category=${c.slug}`}
              className="card p-6 hover:border-primary transition-colors group"
            >
              <div className="font-display text-xl mb-1 group-hover:text-primary transition-colors">{c.name}</div>
              <div className="text-sm text-muted">{c._count?.products ?? 0} товаров</div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-24">
        <div className="flex items-end justify-between mb-8">
          <div>
            <div className="eyebrow mb-2">Выбор покупателей</div>
            <h2 className="font-display text-3xl">Популярное сейчас</h2>
          </div>
          <Link to="/catalog?sort=rating" className="btn-ghost hidden sm:flex">Весь каталог →</Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {featured.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>
    </div>
  );
}
