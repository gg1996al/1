import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore.js';
import { getErrorMessage } from '../api/client.js';

export default function Register() {
  const { register } = useAuthStore();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '' });
  const [error, setError] = useState('');
  const [status, setStatus] = useState('idle');

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus('loading');
    setError('');
    try {
      await register(form);
      navigate('/');
    } catch (err) {
      setStatus('idle');
      setError(getErrorMessage(err));
    }
  }

  return (
    <div className="max-w-sm mx-auto px-4 py-20">
      <h1 className="font-display text-3xl mb-2">Создать аккаунт</h1>
      <p className="text-muted text-sm mb-8">Это займёт меньше минуты.</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <input required placeholder="Имя" value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })} className="input-field" />
        <input required type="email" placeholder="Email" value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })} className="input-field" />
        <input placeholder="Телефон (необязательно)" value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input-field" />
        <input required type="password" placeholder="Пароль, минимум 6 символов" value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })} className="input-field" />
        {error && <p className="text-danger text-sm">{error}</p>}
        <button className="btn-primary w-full" disabled={status === 'loading'}>
          {status === 'loading' ? 'Создаём…' : 'Зарегистрироваться'}
        </button>
      </form>

      <p className="text-sm text-muted mt-6">
        Уже есть аккаунт? <Link to="/login" className="text-primary font-medium hover:underline">Войти</Link>
      </p>
    </div>
  );
}
