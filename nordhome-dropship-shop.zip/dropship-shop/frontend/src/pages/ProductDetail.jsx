import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api, getErrorMessage } from '../api/client.js';
import { useAuthStore } from '../store/authStore.js';
import { useCartStore } from '../store/cartStore.js';

export default function ProductDetail() {
  const { slug } = useParams();
  const { user } = useAuthStore();
  const addItem = useCartStore((s) => s.addItem);

  const [product, setProduct] = useState(null);
  const [activeImage, setActiveImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [status, setStatus] = useState('idle');
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '' });
  const [reviewStatus, setReviewStatus] = useState('idle');

  useEffect(() => {
    setProduct(null);
    api.get(`/products/${slug}`).then((r) => setProduct(r.data.product));
  }, [slug]);

  async function handleAddToCart() {
    setStatus('loading');
    try {
      await addItem(product.id, quantity);
      setStatus('added');
      setTimeout(() => setStatus('idle'), 1800);
    } catch (err) {
      setStatus('idle');
      alert(getErrorMessage(err));
    }
  }

  async function handleReviewSubmit(e) {
    e.preventDefault();
    setReviewStatus('loading');
    try {
      await api.post(`/products/${slug}/reviews`, reviewForm);
      const r = await api.get(`/products/${slug}`);
      setProduct(r.data.product);
      setReviewStatus('done');
      setReviewForm({ rating: 5, comment: '' });
    } catch (err) {
      setReviewStatus('idle');
      alert(getErrorMessage(err));
    }
  }

  if (!product) {
    return <div className="max-w-7xl mx-auto px-4 py-24 text-center text-muted">Загрузка…</div>;
  }

  const discount = product.compareAtPrice && product.compareAtPrice > product.price
    ? Math.round(100 - (product.price / product.compareAtPrice) * 100)
    : null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      <div className="text-sm text-muted mb-6 flex items-center gap-2">
        <Link to="/catalog" className="hover:text-primary">Каталог</Link>
        <span>/</span>
        <Link to={`/catalog?category=${product.category?.slug}`} className="hover:text-primary">{product.category?.name}</Link>
      </div>

      <div className="grid md:grid-cols-2 gap-12 mb-16">
        <div>
          <div className="aspect-square rounded-lg overflow-hidden bg-primary-light mb-3">
            {product.images?.[activeImage] ? (
              <img src={product.images[activeImage]} alt={product.title} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-muted">Нет фото</div>
            )}
          </div>
          {product.images?.length > 1 && (
            <div className="flex gap-2">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImage(i)}
                  className={`w-16 h-16 rounded-sm overflow-hidden border-2 ${i === activeImage ? 'border-primary' : 'border-transparent'}`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        <div>
          <div className="eyebrow mb-2">{product.category?.name} · SKU {product.sku}</div>
          <h1 className="font-display text-3xl mb-3 leading-tight">{product.title}</h1>

          {product.rating > 0 && (
            <div className="flex items-center gap-2 mb-5 text-sm">
              <div className="flex items-center gap-0.5">
                {[1, 2, 3, 4, 5].map((n) => (
                  <svg key={n} className={`w-4 h-4 ${n <= Math.round(product.rating) ? 'text-accent fill-current' : 'text-line fill-current'}`} viewBox="0 0 20 20">
                    <path d="M10 1.5l2.6 5.6 6 .7-4.5 4.1 1.2 6-5.3-3-5.3 3 1.2-6L1.4 7.8l6-.7L10 1.5z" />
                  </svg>
                ))}
              </div>
              <span className="text-muted">{product.rating.toFixed(1)} · {product.reviewsCount} отзывов</span>
            </div>
          )}

          <div className="flex items-baseline gap-3 mb-6">
            <span className="price-tag pl-2 text-2xl font-semibold">${product.price.toFixed(2)}</span>
            {product.compareAtPrice && (
              <>
                <span className="text-muted line-through">${product.compareAtPrice.toFixed(2)}</span>
                <span className="text-danger text-sm font-mono">−{discount}%</span>
              </>
            )}
          </div>

          <p className="text-ink/80 leading-relaxed mb-6">{product.description}</p>

          {Object.keys(product.attributes || {}).length > 0 && (
            <dl className="grid grid-cols-2 gap-y-2 text-sm mb-6 border-t border-line pt-4">
              {Object.entries(product.attributes).map(([k, v]) => (
                <div key={k} className="contents">
                  <dt className="text-muted capitalize">{k}</dt>
                  <dd>{String(v)}</dd>
                </div>
              ))}
            </dl>
          )}

          <div className="text-sm mb-6">
            {product.stock > 0 ? (
              <span className="text-primary font-medium">В наличии на складе поставщика · {product.stock} шт.</span>
            ) : (
              <span className="text-danger font-medium">Нет в наличии</span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center border border-line rounded-sm">
              <button onClick={() => setQuantity((q) => Math.max(1, q - 1))} className="w-10 h-11 hover:bg-primary-light">−</button>
              <span className="w-10 text-center font-mono">{quantity}</span>
              <button onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))} className="w-10 h-11 hover:bg-primary-light">+</button>
            </div>
            <button
              onClick={handleAddToCart}
              disabled={product.stock === 0 || status === 'loading'}
              className="btn-primary flex-1"
            >
              {status === 'added' ? 'Добавлено ✓' : status === 'loading' ? 'Добавляем…' : 'В корзину'}
            </button>
          </div>

          <p className="text-xs text-muted mt-4">
            Доставка напрямую со склада поставщика, 7–14 дней. Оплата картой на следующем шаге.
          </p>
        </div>
      </div>

      {/* Reviews */}
      <section className="max-w-2xl">
        <h2 className="font-display text-2xl mb-6">Отзывы ({product.reviewsCount})</h2>

        {user && (
          <form onSubmit={handleReviewSubmit} className="card p-5 mb-8">
            <div className="flex items-center gap-1 mb-3">
              {[1, 2, 3, 4, 5].map((n) => (
                <button type="button" key={n} onClick={() => setReviewForm((f) => ({ ...f, rating: n }))}>
                  <svg className={`w-6 h-6 ${n <= reviewForm.rating ? 'text-accent fill-current' : 'text-line fill-current'}`} viewBox="0 0 20 20">
                    <path d="M10 1.5l2.6 5.6 6 .7-4.5 4.1 1.2 6-5.3-3-5.3 3 1.2-6L1.4 7.8l6-.7L10 1.5z" />
                  </svg>
                </button>
              ))}
            </div>
            <textarea
              value={reviewForm.comment}
              onChange={(e) => setReviewForm((f) => ({ ...f, comment: e.target.value }))}
              placeholder="Поделитесь впечатлением о товаре…"
              className="input-field mb-3 min-h-[80px]"
            />
            <button className="btn-secondary" disabled={reviewStatus === 'loading'}>
              {reviewStatus === 'loading' ? 'Отправка…' : 'Оставить отзыв'}
            </button>
          </form>
        )}

        {product.reviews?.length === 0 ? (
          <p className="text-muted text-sm">Пока нет отзывов — станьте первым.</p>
        ) : (
          <ul className="space-y-5">
            {product.reviews?.map((r) => (
              <li key={r.id} className="border-b border-line pb-5">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium text-sm">{r.user?.name}</span>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((n) => (
                      <svg key={n} className={`w-3.5 h-3.5 ${n <= r.rating ? 'text-accent fill-current' : 'text-line fill-current'}`} viewBox="0 0 20 20">
                        <path d="M10 1.5l2.6 5.6 6 .7-4.5 4.1 1.2 6-5.3-3-5.3 3 1.2-6L1.4 7.8l6-.7L10 1.5z" />
                      </svg>
                    ))}
                  </div>
                </div>
                {r.comment && <p className="text-sm text-ink/80">{r.comment}</p>}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
