# NordHome — интернет-магазин дропшиппинга (модель посредничества)

Полноценное веб-приложение: маркетплейс перепродаёт товары поставщика с наценкой
(`price - costPrice`), сам не хранит физический склад. После оплаты заказ
автоматически маршрутизируется поставщику через адаптер интеграции.

Ниша демо-каталога: умные гаджеты и вещи для дома.

## Стек

**Backend:** Node.js, Express, Prisma ORM (SQLite из коробки, легко переключить на PostgreSQL),
JWT-аутентификация (access + httpOnly refresh), Stripe Checkout, паттерн "адаптер" для поставщиков.

**Frontend:** React 18, Vite, React Router, Tailwind CSS, Zustand (стейт-менеджмент), Axios.

## Архитектура

```
dropship-shop/
├── backend/
│   ├── prisma/
│   │   ├── schema.prisma      # модель данных
│   │   └── seed.js            # админ + категории + демо-товары
│   └── src/
│       ├── config/db.js       # Prisma client singleton
│       ├── controllers/       # бизнес-логика по доменам
│       ├── middleware/        # auth, validate, errorHandler
│       ├── routes/            # REST-роуты
│       ├── services/
│       │   ├── supplierAdapter.js     # адаптер-паттерн: MOCK / CSV / API
│       │   ├── fulfillmentService.js  # маршрутизация оплаченных заказов поставщику
│       │   └── stripeService.js       # Stripe Checkout + webhook
│       └── utils/
└── frontend/
    └── src/
        ├── api/client.js      # axios + автообновление access-токена
        ├── store/             # zustand: auth, cart
        ├── components/        # Header, Footer, ProductCard, Filters...
        └── pages/
            ├── ...             # каталог, товар, корзина, чекаут, аккаунт
            └── admin/          # дашборд, товары, заказы, поставщики
```

### Ключевая бизнес-логика посредничества

1. `Product.costPrice` — закупочная цена у поставщика, видна только в админке.
2. `Product.price` — розничная цена для покупателя. Маржа = `price - costPrice`,
   считается на лету и показывается в дашборде и списке товаров админки.
3. При оформлении заказа товар резервируется (списывается остаток), создаётся `Order` со статусом `PENDING`.
4. После успешной оплаты (Stripe webhook `checkout.session.completed`) заказ переходит в `PAID`,
   а `fulfillmentService` группирует позиции по поставщикам и вызывает `adapter.placeOrder()` —
   так один заказ может автоматически "расщепиться" на несколько поставщиков.
5. Импорт каталога поставщика (админка → Поставщики) подтягивает товары через адаптер
   и делает upsert по `supplierProductId`, применяя наценку по умолчанию (×1.7), если розничная
   цена явно не задана.

Чтобы подключить реального поставщика (CJ Dropshipping, AliExpress Dropshipping API и т.п.),
достаточно реализовать интерфейс `SupplierAdapter` в `backend/src/services/supplierAdapter.js`
(3 метода: `fetchCatalog`, `placeOrder`, `checkAvailability`) — остальной код меняться не будет.

## Запуск локально

### 1. Backend

```bash
cd backend
cp .env.example .env
npm install
npx prisma migrate dev --name init   # создаст SQLite-базу backend/prisma/dev.db
npm run seed                         # админ + категории + демо-товары
npm run dev                          # http://localhost:4000
```

Данные админа после seed: смотрите вывод в консоли или переменные
`SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` в `.env` (по умолчанию
`admin@nordhome.shop` / `Admin12345!`).

### 2. Frontend

```bash
cd frontend
npm install
npm run dev                          # http://localhost:5173
```

Vite настроен с прокси `/api → http://localhost:4000`, поэтому фронт и бэк
можно запускать параллельно без CORS-проблем в dev-режиме.

### 3. Оплата (опционально)

Чтобы включить реальную оплату картой:
1. Получите тестовые ключи на https://dashboard.stripe.com/test/apikeys
2. Впишите `STRIPE_SECRET_KEY` в `backend/.env`
3. Для локального теста вебхука используйте Stripe CLI:
   `stripe listen --forward-to localhost:4000/api/payments/webhook`
   и впишите выданный `whsec_...` в `STRIPE_WEBHOOK_SECRET`.

Без ключей Stripe оформление заказа всё равно работает — покупатель сразу
попадает на страницу успешного оформления (демо-режим), заказ создаётся в БД
и виден в личном кабинете / админке.

## Переход на продакшен-БД (PostgreSQL)

1. В `backend/prisma/schema.prisma` смените `provider = "sqlite"` на `provider = "postgresql"`.
2. В `.env` укажите `DATABASE_URL="postgresql://user:pass@host:5432/db"`.
3. `npx prisma migrate dev`.

Остальной код не меняется — вся работа с БД идёт через Prisma Client.

## Деплой

- **Backend:** любой Node-хостинг (Railway, Render, Fly.io, VPS + PM2). Не забудьте
  задать все переменные из `.env.example` и запустить `npx prisma migrate deploy`.
- **Frontend:** `npm run build` → статика из `frontend/dist` на Vercel/Netlify/любой CDN.
  Не забудьте поменять `CLIENT_URL` на backend и адрес API в проде (например, через Vite env
  `VITE_API_URL`, если фронт и бэк на разных доменах — сейчас конфиг рассчитан на общий домен
  через reverse-proxy `/api`).

## Безопасность и стандарты, заложенные в проект

- Пароли — bcrypt, JWT с коротким access-токеном + httpOnly refresh-cookie.
- Rate-limiting на API, отдельно ужесточён на логин/регистрацию.
- Helmet, CORS с явным origin, express-validator на входных данных.
- Себестоимость товара (`costPrice`) никогда не отдаётся в публичном API — только в admin-роутах.
- Snapshot-поля в `OrderItem` (цена/себестоимость/название на момент покупки) —
  история заказов не "плывёт" при последующем редактировании каталога.
- Транзакции Prisma при создании заказа (резерв склада + создание заказа атомарны).
