import { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCartStore } from '../store/cartStore.js';
import { useAuthStore } from '../store/authStore.js';

export default function Cart() {
  const { items, subtotal, fetchCart, updateItem, removeItem } = useCartStore();
  const { user } = useAuthStore();
  const navigate = useNavigate();

  useEffect(() => { if (user) fetchCart(); }, [user]);

  if (!user) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-24 text-center">
        <h1 className="font-display text-3xl mb-4">Корзина</h1>
        <p className="text-muted mb-6">Войдите, чтобы увидеть свою корзину.</p>
        <Link to="/login" className="btn-primary">Войти</Link>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-24 text-center">
        <h1 className="font-display text-3xl mb-4">Корзина пуста</h1>
        <p className="text-muted mb-6">Добавьте товары из каталога, чтобы оформить заказ.</p>
        <Link to="/catalog" className="btn-primary">В каталог</Link>
      </div>
    );
  }

  const freeShippingLeft = Math.max(0, 60 - subtotal);
  const shipping = subtotal >= 60 ? 0 : 4.99;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10">
      <h1 className="font-display text-3xl mb-8">Корзина</h1>

      {freeShippingLeft > 0 ? (
        <div className="bg-accent-light text-accent-dark text-sm px-4 py-3 rounded-sm mb-6">
          Добавьте товаров ещё на <strong>${freeShippingLeft.toFixed(2)}</strong> — и доставка будет бесплатной.
        </div>
      ) : (
        <div className="bg-primary-light text-primary text-sm px-4 py-3 rounded-sm mb-6">
          Бесплатная доставка уже действует для этого заказа ✓
        </div>
      )}

      <div className="grid md:grid-cols-[1fr_320px] gap-10">
        <ul className="divide-y divide-line">
          {items.map((item) => (
            <li key={item.id} className="py-5 flex gap-4">
              <Link to={`/product/${item.product.slug}`} className="w-20 h-20 rounded-sm overflow-hidden bg-primary-light shrink-0">
                {item.product.images?.[0] && <img src={item.product.images[0]} alt="" className="w-full h-full object-cover" />}
              </Link>
              <div className="flex-1 min-w-0">
                <Link to={`/product/${item.product.slug}`} className="font-medium text-sm hover:text-primary transition-colors line-clamp-2">
                  {item.product.title}
                </Link>
                <div className="price-tag pl-2 text-sm mt-1">${item.product.price.toFixed(2)}</div>
                <div className="flex items-center gap-3 mt-3">
                  <div className="flex items-center border border-line rounded-sm">
                    <button onClick={() => updateItem(item.id, item.quantity - 1)} className="w-8 h-8 hover:bg-primary-light text-sm">−</button>
                    <span className="w-8 text-center font-mono text-sm">{item.quantity}</span>
                    <button onClick={() => updateItem(item.id, item.quantity + 1)} className="w-8 h-8 hover:bg-primary-light text-sm">+</button>
                  </div>
                  <button onClick={() => removeItem(item.id)} className="text-xs text-muted hover:text-danger transition-colors">
                    Удалить
                  </button>
                </div>
              </div>
              <div className="font-mono text-sm font-medium shrink-0">
                ${(item.product.price * item.quantity).toFixed(2)}
              </div>
            </li>
          ))}
        </ul>

        <div className="card p-6 h-fit">
          <h2 className="font-display text-lg mb-4">Итого</h2>
          <div className="space-y-2 text-sm mb-4">
            <div className="flex justify-between"><span className="text-muted">Товары</span><span className="font-mono">${subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between"><span className="text-muted">Доставка</span><span className="font-mono">{shipping === 0 ? 'Бесплатно' : `$${shipping.toFixed(2)}`}</span></div>
          </div>
          <div className="flex justify-between border-t border-line pt-4 mb-6 font-medium">
            <span>К оплате</span>
            <span className="font-mono text-lg">${(subtotal + shipping).toFixed(2)}</span>
          </div>
          <button onClick={() => navigate('/checkout')} className="btn-primary w-full">Оформить заказ</button>
        </div>
      </div>
    </div>
  );
}
