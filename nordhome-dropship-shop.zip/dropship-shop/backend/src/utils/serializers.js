// Prisma + SQLite хранит массивы/объекты как JSON-строки (см. schema.prisma),
// эти хелперы приводят их к нормальному виду для JSON-ответов API и обратно при записи.

export function serializeProduct(product, { includeCost = false } = {}) {
  if (!product) return product;
  const { imagesJson, attributesJson, costPrice, ...rest } = product;
  const out = {
    ...rest,
    images: safeParse(imagesJson, []),
    attributes: safeParse(attributesJson, {}),
  };
  if (includeCost) {
    out.costPrice = costPrice;
    out.margin = Number((product.price - costPrice).toFixed(2));
    out.marginPercent = costPrice > 0 ? Number((((product.price - costPrice) / product.price) * 100).toFixed(1)) : null;
  }
  return out;
}

export function serializeOrder(order) {
  if (!order) return order;
  const { shippingAddressJson, ...rest } = order;
  return {
    ...rest,
    shippingAddress: safeParse(shippingAddressJson, {}),
  };
}

function safeParse(str, fallback) {
  try {
    return JSON.parse(str ?? '');
  } catch {
    return fallback;
  }
}
