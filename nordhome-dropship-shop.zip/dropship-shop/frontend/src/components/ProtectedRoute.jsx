import { Navigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore.js';

export default function ProtectedRoute({ children, adminOnly = false }) {
  const { user, isReady } = useAuthStore();

  if (!isReady) {
    return <div className="max-w-7xl mx-auto px-4 py-24 text-center text-muted">Загрузка…</div>;
  }
  if (!user) return <Navigate to="/login" replace />;
  if (adminOnly && user.role !== 'ADMIN') return <Navigate to="/" replace />;

  return children;
}
