import { NavLink, Outlet } from 'react-router-dom';

const NAV = [
  { to: '/admin', label: 'Дашборд', end: true },
  { to: '/admin/products', label: 'Товары' },
  { to: '/admin/orders', label: 'Заказы' },
  { to: '/admin/suppliers', label: 'Поставщики' },
];

export default function AdminLayout() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      <div className="eyebrow mb-2">Панель управления</div>
      <h1 className="font-display text-3xl mb-8">Админка NordHome</h1>

      <div className="grid md:grid-cols-[200px_1fr] gap-10">
        <nav className="space-y-1">
          {NAV.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `block px-3 py-2 rounded-sm text-sm font-medium transition-colors ${
                  isActive ? 'bg-primary text-white' : 'text-ink/80 hover:bg-primary-light'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="min-w-0">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
