import { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api/client.js';
import ProductCard from '../components/ProductCard.jsx';
import Filters from '../components/Filters.jsx';

export default function Catalog() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [isLoading, setIsLoading] = useState(true);

  const filters = {
    search: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    minPrice: searchParams.get('minPrice') || '',
    maxPrice: searchParams.get('maxPrice') || '',
    sort: searchParams.get('sort') || 'newest',
    page: searchParams.get('page') || '1',
  };

  const updateFilters = useCallback((patch) => {
    const next = new URLSearchParams(searchParams);
    Object.entries(patch).forEach(([key, value]) => {
      if (value) next.set(key, value); else next.delete(key);
    });
    if (!('page' in patch)) next.delete('page');
    setSearchParams(next);
  }, [searchParams, setSearchParams]);

  useEffect(() => {
    api.get('/products/categories').then((r) => setCategories(r.data.categories));
  }, []);

  useEffect(() => {
    setIsLoading(true);
    api.get('/products', { params: filters }).then((r) => {
      setItems(r.data.items);
      setTotal(r.data.total);
      setTotalPages(r.data.totalPages);
      setIsLoading(false);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams.toString()]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      <div className="mb-8">
        <div className="eyebrow mb-2">Каталог</div>
        <h1 className="font-display text-3xl">
          {filters.search ? `Результаты по запросу «${filters.search}»` : 'Все товары'}
        </h1>
        <p className="text-muted text-sm mt-1">{total} товаров</p>
      </div>

      <div className="grid md:grid-cols-[220px_1fr] gap-10">
        <Filters categories={categories} filters={filters} onChange={updateFilters} />

        <div>
          {isLoading ? (
            <div className="text-center py-20 text-muted">Загрузка…</div>
          ) : items.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-muted mb-4">По вашему запросу ничего не найдено.</p>
              <button onClick={() => setSearchParams({})} className="btn-ghost">Сбросить фильтры</button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-5">
                {items.map((p) => <ProductCard key={p.id} product={p} />)}
              </div>

              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 mt-10 font-mono text-sm">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                    <button
                      key={p}
                      onClick={() => updateFilters({ page: String(p) })}
                      className={`w-9 h-9 rounded-sm transition-colors ${
                        Number(filters.page) === p ? 'bg-primary text-white' : 'hover:bg-primary-light'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
