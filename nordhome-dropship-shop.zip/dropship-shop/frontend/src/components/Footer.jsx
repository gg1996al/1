import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="border-t border-line mt-24 bg-surface">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-14 grid grid-cols-2 md:grid-cols-4 gap-8">
        <div className="col-span-2 md:col-span-1">
          <div className="font-display text-xl mb-3">NordHome</div>
          <p className="text-sm text-muted leading-relaxed">
            Вещи для дома напрямую со склада поставщика — без лишних наценок посредников-перекупщиков.
          </p>
        </div>
        <div>
          <div className="eyebrow mb-3">Каталог</div>
          <ul className="space-y-2 text-sm text-muted">
            <li><Link to="/catalog" className="hover:text-primary transition-colors">Все товары</Link></li>
            <li><Link to="/catalog?sort=newest" className="hover:text-primary transition-colors">Новинки</Link></li>
            <li><Link to="/catalog?sort=rating" className="hover:text-primary transition-colors">Популярное</Link></li>
          </ul>
        </div>
        <div>
          <div className="eyebrow mb-3">Покупателям</div>
          <ul className="space-y-2 text-sm text-muted">
            <li><Link to="/account" className="hover:text-primary transition-colors">Мои заказы</Link></li>
            <li>Доставка 7–14 дней</li>
            <li>Оплата картой онлайн</li>
          </ul>
        </div>
        <div>
          <div className="eyebrow mb-3">Контакты</div>
          <ul className="space-y-2 text-sm text-muted">
            <li>support@nordhome.shop</li>
            <li>Пн–Пт, 9:00–18:00</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-line py-4 text-center text-xs text-muted font-mono">
        © {new Date().getFullYear()} NordHome — демонстрационный проект
      </div>
    </footer>
  );
}
