import { Router } from 'express';
import { body } from 'express-validator';
import { listProducts, getProductBySlug, listCategories, addReview } from '../controllers/productController.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = Router();

router.get('/', listProducts);
router.get('/categories', listCategories);
router.get('/:slug', getProductBySlug);
router.post(
  '/:slug/reviews',
  requireAuth,
  [body('rating').isInt({ min: 1, max: 5 }), body('comment').optional().isString()],
  validate,
  addReview
);

export default router;
