import { ApiError } from '../utils/ApiError.js';

export function notFoundHandler(req, res, next) {
  next(ApiError.notFound(`Маршрут ${req.method} ${req.originalUrl} не найден`));
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  if (err instanceof ApiError) {
    return res.status(err.statusCode).json({
      error: err.message,
      details: err.details ?? undefined,
    });
  }

  // Ошибки уникальности Prisma и т.п.
  if (err.code === 'P2002') {
    return res.status(409).json({
      error: 'Запись с такими данными уже существует',
      details: err.meta?.target,
    });
  }
  if (err.code === 'P2025') {
    return res.status(404).json({ error: 'Запись не найдена' });
  }

  console.error(err);
  return res.status(500).json({ error: 'Внутренняя ошибка сервера' });
}
