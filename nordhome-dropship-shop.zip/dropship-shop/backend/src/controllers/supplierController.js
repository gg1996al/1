import slugify from 'slugify';
import { prisma } from '../config/db.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { ApiError } from '../utils/ApiError.js';
import { getAdapter, DEFAULT_MARKUP_MULTIPLIER } from '../services/supplierAdapter.js';

export const listSuppliers = asyncHandler(async (req, res) => {
  const suppliers = await prisma.supplier.findMany({
    include: { _count: { select: { products: true } } },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ suppliers });
});

export const createSupplier = asyncHandler(async (req, res) => {
  const { name, type = 'MOCK', config = {} } = req.body;
  const supplier = await prisma.supplier.create({
    data: { name, type, configJson: JSON.stringify(config) },
  });
  res.status(201).json({ supplier });
});

/**
 * Импорт каталога поставщика в магазин: тянет товары через адаптер и делает upsert
 * по externalId (сохранённому в supplierProductId), проставляя розничную цену
 * с наценкой по умолчанию, если явно не задана. Обновляет остатки для уже существующих товаров.
 */
export const importCatalog = asyncHandler(async (req, res) => {
  const supplier = await prisma.supplier.findUnique({ where: { id: req.params.id } });
  if (!supplier) throw ApiError.notFound('Поставщик не найден');

  let { categoryId, markupMultiplier } = req.body;
  if (!categoryId) {
    const anyCategory = await prisma.category.findFirst();
    if (!anyCategory) throw ApiError.badRequest('Сначала создайте хотя бы одну категорию');
    categoryId = anyCategory.id;
  }
  const markup = Number(markupMultiplier) || DEFAULT_MARKUP_MULTIPLIER;

  const adapter = getAdapter(supplier.type);
  const config = { ...JSON.parse(supplier.configJson || '{}'), csvContent: req.body.csvContent };
  const catalog = await adapter.fetchCatalog(config);

  let created = 0;
  let updated = 0;

  for (const item of catalog) {
    const existing = await prisma.product.findFirst({
      where: { supplierId: supplier.id, supplierProductId: item.externalId },
    });

    const retailPrice = item.suggestedRetailPrice || Number((item.costPrice * markup).toFixed(2));

    if (existing) {
      await prisma.product.update({
        where: { id: existing.id },
        data: { stock: item.stock, costPrice: item.costPrice },
      });
      updated += 1;
    } else {
      const slug = await uniqueSlug(item.title);
      await prisma.product.create({
        data: {
          title: item.title,
          slug,
          description: item.description,
          price: retailPrice,
          costPrice: item.costPrice,
          sku: item.sku || `${supplier.id.slice(0, 4)}-${item.externalId}`,
          stock: item.stock,
          imagesJson: JSON.stringify(item.images || []),
          attributesJson: JSON.stringify(item.attributes || {}),
          categoryId,
          supplierId: supplier.id,
          supplierProductId: item.externalId,
        },
      });
      created += 1;
    }
  }

  res.json({ message: `Импорт завершён: добавлено ${created}, обновлено ${updated}`, created, updated, total: catalog.length });
});

async function uniqueSlug(title) {
  const base = slugify(title, { lower: true, strict: true, locale: 'ru' });
  let slug = base;
  let i = 1;
  while (await prisma.product.findFirst({ where: { slug } })) {
    slug = `${base}-${++i}`;
  }
  return slug;
}
