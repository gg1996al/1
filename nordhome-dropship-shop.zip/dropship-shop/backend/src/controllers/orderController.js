import { prisma } from '../config/db.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { ApiError } from '../utils/ApiError.js';
import { serializeOrder } from '../utils/serializers.js';

const FLAT_SHIPPING_RATE = 4.99;
const FREE_SHIPPING_THRESHOLD = 60;

function generateOrderNumber() {
  const rand = Math.floor(100000 + Math.random() * 900000);
  return `NH-${rand}`;
}

// POST /api/orders — оформление заказа из текущей корзины пользователя
export const createOrder = asyncHandler(async (req, res) => {
  const { shippingAddress } = req.body;
  if (!shippingAddress?.fullName || !shippingAddress?.city || !shippingAddress?.street) {
    throw ApiError.badRequest('Укажите полный адрес доставки');
  }

  const cartItems = await prisma.cartItem.findMany({
    where: { userId: req.user.id },
    include: { product: true },
  });
  if (cartItems.length === 0) throw ApiError.badRequest('Корзина пуста');

  for (const item of cartItems) {
    if (!item.product.isActive) throw ApiError.badRequest(`Товар «${item.product.title}» больше недоступен`);
    if (item.product.stock < item.quantity) {
      throw ApiError.badRequest(`Недостаточно товара «${item.product.title}» на складе поставщика`);
    }
  }

  const subtotal = cartItems.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  const shippingCost = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : FLAT_SHIPPING_RATE;
  const total = Number((subtotal + shippingCost).toFixed(2));

  const order = await prisma.$transaction(async (tx) => {
    const created = await tx.order.create({
      data: {
        orderNumber: generateOrderNumber(),
        userId: req.user.id,
        subtotal: Number(subtotal.toFixed(2)),
        shippingCost,
        total,
        shippingAddressJson: JSON.stringify(shippingAddress),
        items: {
          create: cartItems.map((i) => ({
            productId: i.productId,
            titleSnapshot: i.product.title,
            priceSnapshot: i.product.price,
            costSnapshot: i.product.costPrice,
            quantity: i.quantity,
            supplierId: i.product.supplierId,
          })),
        },
      },
      include: { items: true },
    });

    // Резервируем товар на складе поставщика сразу при создании заказа,
    // чтобы избежать перепродажи, пока покупатель не завершил оплату.
    for (const i of cartItems) {
      await tx.product.update({
        where: { id: i.productId },
        data: { stock: { decrement: i.quantity } },
      });
    }
    await tx.cartItem.deleteMany({ where: { userId: req.user.id } });

    return created;
  });

  res.status(201).json({ order: serializeOrder(order) });
});

export const listMyOrders = asyncHandler(async (req, res) => {
  const orders = await prisma.order.findMany({
    where: { userId: req.user.id },
    include: { items: true },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ orders: orders.map(serializeOrder) });
});

export const getMyOrder = asyncHandler(async (req, res) => {
  const order = await prisma.order.findUnique({
    where: { id: req.params.id },
    include: { items: true },
  });
  if (!order || order.userId !== req.user.id) throw ApiError.notFound('Заказ не найден');
  res.json({ order: serializeOrder(order) });
});
