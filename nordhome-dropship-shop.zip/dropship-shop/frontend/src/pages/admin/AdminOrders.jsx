import { useEffect, useState } from 'react';
import { api } from '../../api/client.js';

const STATUSES = ['PENDING', 'PAID', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED', 'REFUNDED'];

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [statusFilter, setStatusFilter] = useState('');

  async function load() {
    const { data } = await api.get('/admin/orders', { params: statusFilter ? { status: statusFilter } : {} });
    setOrders(data.items);
  }

  useEffect(() => { load(); }, [statusFilter]);

  async function updateStatus(id, status) {
    await api.patch(`/admin/orders/${id}/status`, { status });
    load();
  }

  return (
    <div>
      <div className="mb-6">
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="input-field max-w-xs">
          <option value="">Все статусы</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      <div className="card divide-y divide-line">
        {orders.map((o) => (
          <div key={o.id} className="p-4">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
              <div>
                <span className="font-mono font-medium">{o.orderNumber}</span>
                <span className="text-sm text-muted ml-2">{o.user?.name} · {o.user?.email}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-mono font-medium">${o.total.toFixed(2)}</span>
                <select
                  value={o.status}
                  onChange={(e) => updateStatus(o.id, e.target.value)}
                  className="input-field !py-1 !w-auto text-sm"
                >
                  {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <ul className="text-xs text-muted space-y-0.5">
              {o.items.map((i) => (
                <li key={i.id}>
                  {i.titleSnapshot} × {i.quantity}
                  {i.supplierOrderRef && <span className="text-primary ml-2">→ {i.supplierOrderRef}</span>}
                </li>
              ))}
            </ul>
          </div>
        ))}
        {orders.length === 0 && <p className="p-6 text-center text-muted text-sm">Заказов пока нет.</p>}
      </div>
    </div>
  );
}
