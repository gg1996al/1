import { useEffect, useState } from 'react';
import { api, getErrorMessage } from '../../api/client.js';

export default function AdminSuppliers() {
  const [suppliers, setSuppliers] = useState([]);
  const [categories, setCategories] = useState([]);
  const [newSupplier, setNewSupplier] = useState({ name: '', type: 'MOCK' });
  const [importState, setImportState] = useState({}); // supplierId -> { categoryId, csvFile, status, message }

  async function load() {
    const [s, c] = await Promise.all([api.get('/admin/suppliers'), api.get('/products/categories')]);
    setSuppliers(s.data.suppliers);
    setCategories(c.data.categories);
  }

  useEffect(() => { load(); }, []);

  async function handleCreateSupplier(e) {
    e.preventDefault();
    await api.post('/admin/suppliers', newSupplier);
    setNewSupplier({ name: '', type: 'MOCK' });
    load();
  }

  function setImport(id, patch) {
    setImportState((s) => ({ ...s, [id]: { ...s[id], ...patch } }));
  }

  async function handleImport(supplier) {
    const state = importState[supplier.id] || {};
    setImport(supplier.id, { status: 'loading', message: '' });
    try {
      let csvContent = null;
      if (supplier.type === 'CSV') {
        if (!state.csvFile) throw new Error('Выберите CSV-файл для импорта');
        csvContent = await state.csvFile.text();
      }
      const { data } = await api.post(`/admin/suppliers/${supplier.id}/import`, {
        categoryId: state.categoryId || undefined,
        csvContent,
      });
      setImport(supplier.id, { status: 'done', message: data.message });
      load();
    } catch (err) {
      setImport(supplier.id, { status: 'error', message: err.message || getErrorMessage(err) });
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="font-display text-xl mb-4">Новый поставщик</h2>
        <form onSubmit={handleCreateSupplier} className="card p-5 flex flex-wrap items-end gap-3">
          <div className="flex-1 min-w-[180px]">
            <label className="text-xs text-muted block mb-1">Название</label>
            <input required value={newSupplier.name} onChange={(e) => setNewSupplier({ ...newSupplier, name: e.target.value })} className="input-field" placeholder="Например, CJ Dropshipping" />
          </div>
          <div>
            <label className="text-xs text-muted block mb-1">Тип интеграции</label>
            <select value={newSupplier.type} onChange={(e) => setNewSupplier({ ...newSupplier, type: e.target.value })} className="input-field">
              <option value="MOCK">Демо-каталог (MOCK)</option>
              <option value="CSV">CSV-прайс</option>
              <option value="API">Внешний API</option>
            </select>
          </div>
          <button className="btn-primary">Добавить</button>
        </form>
        <p className="text-xs text-muted mt-2">
          Для CSV ожидаются колонки: external_id, title, description, cost_price, retail_price, stock, sku, images (через "|"), attributes (JSON).
        </p>
      </div>

      <div>
        <h2 className="font-display text-xl mb-4">Поставщики и импорт каталога</h2>
        <div className="space-y-4">
          {suppliers.map((s) => {
            const state = importState[s.id] || {};
            return (
              <div key={s.id} className="card p-5">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <span className="font-medium">{s.name}</span>
                    <span className="text-xs text-muted font-mono ml-2">{s.type}</span>
                  </div>
                  <span className="text-sm text-muted">{s._count?.products ?? 0} товаров в каталоге</span>
                </div>

                <div className="flex flex-wrap items-end gap-3">
                  <div>
                    <label className="text-xs text-muted block mb-1">Категория для новых товаров</label>
                    <select
                      value={state.categoryId || ''}
                      onChange={(e) => setImport(s.id, { categoryId: e.target.value })}
                      className="input-field !py-1.5"
                    >
                      <option value="">По умолчанию</option>
                      {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </div>

                  {s.type === 'CSV' && (
                    <div>
                      <label className="text-xs text-muted block mb-1">CSV-файл</label>
                      <input
                        type="file"
                        accept=".csv"
                        onChange={(e) => setImport(s.id, { csvFile: e.target.files[0] })}
                        className="text-sm"
                      />
                    </div>
                  )}

                  <button onClick={() => handleImport(s)} disabled={state.status === 'loading'} className="btn-primary">
                    {state.status === 'loading' ? 'Импортируем…' : 'Импортировать каталог'}
                  </button>
                </div>

                {state.message && (
                  <p className={`text-sm mt-3 ${state.status === 'error' ? 'text-danger' : 'text-primary'}`}>
                    {state.message}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
