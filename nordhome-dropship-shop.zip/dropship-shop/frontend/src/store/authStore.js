import { create } from 'zustand';
import { api, setAccessToken } from '../api/client.js';

export const useAuthStore = create((set, get) => ({
  user: null,
  isReady: false, // true после первой попытки восстановить сессию

  async init() {
    try {
      const { data } = await api.post('/auth/refresh');
      setAccessToken(data.accessToken);
      const me = await api.get('/auth/me');
      set({ user: me.data.user, isReady: true });
    } catch {
      set({ user: null, isReady: true });
    }
  },

  async login(email, password) {
    const { data } = await api.post('/auth/login', { email, password });
    setAccessToken(data.accessToken);
    set({ user: data.user });
  },

  async register(payload) {
    const { data } = await api.post('/auth/register', payload);
    setAccessToken(data.accessToken);
    set({ user: data.user });
  },

  async logout() {
    await api.post('/auth/logout');
    setAccessToken(null);
    set({ user: null });
  },

  isAdmin() {
    return get().user?.role === 'ADMIN';
  },
}));
