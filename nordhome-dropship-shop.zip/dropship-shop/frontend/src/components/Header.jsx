import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore.js';
import { useCartStore } from '../store/cartStore.js';

export default function Header() {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const itemCount = useCartStore((s) => s.itemCount);
  const [query, setQuery] = useState('');

  function handleSearch(e) {
    e.preventDefault();
    navigate(query.trim() ? `/catalog?search=${encodeURIComponent(query.trim())}` : '/catalog');
  }

  return (
    <header className="sticky top-0 z-40 bg-bg/95 backdrop-blur border-b border-line">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center gap-6 h-16">
          <Link to="/" className="font-display text-2xl tracking-tight text-ink shrink-0">
            NordHome
          </Link>

          <nav className="hidden md:flex items-center gap-5 text-sm font-medium text-ink/80">
            <Link to="/catalog" className="hover:text-primary transition-colors">Каталог</Link>
            <Link to="/catalog?category=umnyj-dom" className="hover:text-primary transition-colors">Умный дом</Link>
            <Link to="/catalog?category=kuhnya" className="hover:text-primary transition-colors">Кухня</Link>
          </nav>

          <form onSubmit={handleSearch} className="flex-1 max-w-md ml-auto hidden sm:block">
            <div className="relative">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Поиск товаров…"
                className="w-full bg-surface border border-line rounded-sm pl-9 pr-3 py-2 text-sm placeholder:text-muted focus:border-primary focus:outline-none"
              />
              <svg className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <circle cx="11" cy="11" r="7" />
                <path d="M21 21l-4.3-4.3" strokeLinecap="round" />
              </svg>
            </div>
          </form>

          <div className="flex items-center gap-4 ml-auto sm:ml-0">
            {user ? (
              <div className="hidden sm:flex items-center gap-4">
                {user.role === 'ADMIN' && (
                  <Link to="/admin" className="text-sm font-medium text-accent-dark hover:text-accent transition-colors">
                    Админка
                  </Link>
                )}
                <Link to="/account" className="text-sm font-medium hover:text-primary transition-colors">
                  {user.name.split(' ')[0]}
                </Link>
                <button onClick={logout} className="text-sm text-muted hover:text-ink transition-colors">
                  Выйти
                </button>
              </div>
            ) : (
              <Link to="/login" className="text-sm font-medium hover:text-primary transition-colors hidden sm:block">
                Войти
              </Link>
            )}

            <Link to="/cart" className="relative flex items-center justify-center w-10 h-10 rounded-sm hover:bg-primary-light transition-colors" aria-label="Корзина">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path d="M3 3h2l.4 2M7 13h10l3.6-8H5.4M7 13L5.4 5M7 13l-1.7 4.6A1 1 0 006.2 19H17" strokeLinecap="round" strokeLinejoin="round" />
                <circle cx="9" cy="21.5" r="1.4" />
                <circle cx="17" cy="21.5" r="1.4" />
              </svg>
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-white text-[10px] font-mono leading-none rounded-full w-4.5 h-4.5 min-w-[18px] h-[18px] flex items-center justify-center">
                  {itemCount}
                </span>
              )}
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
