import { create } from 'zustand';
import { api } from '../api/client.js';

export const useCartStore = create((set) => ({
  items: [],
  subtotal: 0,
  itemCount: 0,
  isLoading: false,

  async fetchCart() {
    set({ isLoading: true });
    try {
      const { data } = await api.get('/cart');
      set({ items: data.items, subtotal: data.subtotal, itemCount: data.itemCount, isLoading: false });
    } catch {
      set({ isLoading: false });
    }
  },

  async addItem(productId, quantity = 1) {
    const { data } = await api.post('/cart/items', { productId, quantity });
    set({ items: data.items, subtotal: data.subtotal, itemCount: data.itemCount });
  },

  async updateItem(itemId, quantity) {
    const { data } = await api.patch(`/cart/items/${itemId}`, { quantity });
    set({ items: data.items, subtotal: data.subtotal, itemCount: data.itemCount });
  },

  async removeItem(itemId) {
    const { data } = await api.delete(`/cart/items/${itemId}`);
    set({ items: data.items, subtotal: data.subtotal, itemCount: data.itemCount });
  },

  reset() {
    set({ items: [], subtotal: 0, itemCount: 0 });
  },
}));
