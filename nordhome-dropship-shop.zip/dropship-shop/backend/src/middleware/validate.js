import { validationResult } from 'express-validator';
import { ApiError } from '../utils/ApiError.js';

// Ставится после массива express-validator правил в роуте:
// router.post('/x', [body('email').isEmail(), ...], validate, controller)
export function validate(req, res, next) {
  const result = validationResult(req);
  if (!result.isEmpty()) {
    return next(
      ApiError.badRequest(
        'Данные не прошли валидацию',
        result.array().map((e) => ({ field: e.path, message: e.msg }))
      )
    );
  }
  next();
}
