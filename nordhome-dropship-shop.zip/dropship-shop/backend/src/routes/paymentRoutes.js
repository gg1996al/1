import { Router } from 'express';
import { createSession } from '../controllers/paymentController.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.post('/create-checkout-session', requireAuth, createSession);

export default router;
