import 'dotenv/config';
import bcrypt from 'bcryptjs';
import slugify from 'slugify';
import { PrismaClient } from '@prisma/client';
import { getAdapter, DEFAULT_MARKUP_MULTIPLIER } from '../src/services/supplierAdapter.js';

const prisma = new PrismaClient();

const CATEGORIES = [
  { name: 'Умный дом', description: 'Гаджеты для автоматизации и комфорта дома' },
  { name: 'Кухня', description: 'Товары для кухни и готовки' },
  { name: 'Уют и декор', description: 'Текстиль и мелочи для интерьера' },
  { name: 'Уборка и хранение', description: 'Организация пространства и техника для уборки' },
];

async function main() {
  console.log('🌱 Заполнение базы данных демо-данными...');

  const adminEmail = process.env.SEED_ADMIN_EMAIL || 'admin@nordhome.shop';
  const adminPassword = process.env.SEED_ADMIN_PASSWORD || 'Admin12345!';
  const passwordHash = await bcrypt.hash(adminPassword, 10);

  await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: { email: adminEmail, passwordHash, name: 'Администратор NordHome', role: 'ADMIN' },
  });
  console.log(`✅ Админ: ${adminEmail} / ${adminPassword}`);

  const categoryMap = {};
  for (const c of CATEGORIES) {
    const slug = slugify(c.name, { lower: true, strict: true, locale: 'ru' });
    const cat = await prisma.category.upsert({
      where: { slug },
      update: {},
      create: { ...c, slug },
    });
    categoryMap[c.name] = cat.id;
  }
  console.log(`✅ Категорий: ${CATEGORIES.length}`);

  const supplier = await prisma.supplier.upsert({
    where: { id: 'demo-supplier-seed' },
    update: {},
    create: {
      id: 'demo-supplier-seed',
      name: 'DemoSupply Co.',
      type: 'MOCK',
      configJson: '{}',
    },
  }).catch(async () => {
    // upsert по id сработает только если запись уже существует с этим id при повторном запуске;
    // при первом запуске создаём напрямую.
    const existing = await prisma.supplier.findFirst({ where: { name: 'DemoSupply Co.' } });
    if (existing) return existing;
    return prisma.supplier.create({ data: { id: 'demo-supplier-seed', name: 'DemoSupply Co.', type: 'MOCK', configJson: '{}' } });
  });

  const adapter = getAdapter('MOCK');
  const catalog = await adapter.fetchCatalog({});

  const categoryIds = Object.values(categoryMap);
  let i = 0;
  for (const item of catalog) {
    const existing = await prisma.product.findFirst({ where: { supplierProductId: item.externalId } });
    if (existing) continue;

    const slug = slugify(item.title, { lower: true, strict: true, locale: 'ru' });
    await prisma.product.create({
      data: {
        title: item.title,
        slug,
        description: item.description,
        price: item.suggestedRetailPrice || Number((item.costPrice * DEFAULT_MARKUP_MULTIPLIER).toFixed(2)),
        compareAtPrice: Math.random() > 0.5 ? Number((item.suggestedRetailPrice * 1.25).toFixed(2)) : null,
        costPrice: item.costPrice,
        sku: item.sku,
        stock: item.stock,
        imagesJson: JSON.stringify(item.images || []),
        attributesJson: JSON.stringify(item.attributes || {}),
        categoryId: categoryIds[i % categoryIds.length],
        supplierId: supplier.id,
        supplierProductId: item.externalId,
        rating: Number((3.8 + Math.random() * 1.2).toFixed(1)),
        reviewsCount: Math.floor(Math.random() * 120),
      },
    });
    i += 1;
  }
  console.log(`✅ Товаров импортировано: ${i}`);
  console.log('🎉 Готово. Запустите backend: npm run dev');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
