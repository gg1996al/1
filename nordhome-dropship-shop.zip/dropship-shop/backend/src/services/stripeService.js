import Stripe from 'stripe';

let stripeClient = null;

function getStripe() {
  if (!stripeClient) {
    if (!process.env.STRIPE_SECRET_KEY || process.env.STRIPE_SECRET_KEY.includes('...')) {
      throw new Error(
        'STRIPE_SECRET_KEY не настроен. Добавьте тестовый ключ Stripe в backend/.env, чтобы включить оплату.'
      );
    }
    stripeClient = new Stripe(process.env.STRIPE_SECRET_KEY);
  }
  return stripeClient;
}

// Создаёт Stripe Checkout Session на сумму заказа. Redirect-модель — самый простой
// и безопасный способ принимать карты, не обрабатывая номера карт на своём сервере.
export async function createCheckoutSession({ order, successUrl, cancelUrl, customerEmail }) {
  const stripe = getStripe();

  const line_items = order.items.map((item) => ({
    price_data: {
      currency: 'usd',
      product_data: { name: item.titleSnapshot },
      unit_amount: Math.round(item.priceSnapshot * 100),
    },
    quantity: item.quantity,
  }));

  if (order.shippingCost > 0) {
    line_items.push({
      price_data: {
        currency: 'usd',
        product_data: { name: 'Доставка' },
        unit_amount: Math.round(order.shippingCost * 100),
      },
      quantity: 1,
    });
  }

  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    payment_method_types: ['card'],
    line_items,
    customer_email: customerEmail,
    metadata: { orderId: order.id, orderNumber: order.orderNumber },
    success_url: successUrl,
    cancel_url: cancelUrl,
  });

  return session;
}

export function constructWebhookEvent(rawBody, signature) {
  const stripe = getStripe();
  return stripe.webhooks.constructEvent(rawBody, signature, process.env.STRIPE_WEBHOOK_SECRET);
}
