import { Link } from 'react-router-dom';

export default function ProductCard({ product }) {
  const discount = product.compareAtPrice && product.compareAtPrice > product.price
    ? Math.round(100 - (product.price / product.compareAtPrice) * 100)
    : null;

  return (
    <Link to={`/product/${product.slug}`} className="group block">
      <div className="card overflow-hidden">
        <div className="relative aspect-square bg-primary-light overflow-hidden">
          {product.images?.[0] ? (
            <img
              src={product.images[0]}
              alt={product.title}
              loading="lazy"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted text-sm">Нет фото</div>
          )}
          {discount && (
            <span className="absolute top-3 left-3 bg-danger text-white text-xs font-mono px-2 py-1 rounded-sm">
              −{discount}%
            </span>
          )}
          {product.stock <= 5 && product.stock > 0 && (
            <span className="absolute top-3 right-3 bg-surface/90 text-danger text-xs font-mono px-2 py-1 rounded-sm border border-danger/20">
              Осталось {product.stock}
            </span>
          )}
        </div>
        <div className="p-4">
          <div className="text-xs text-muted mb-1">{product.category?.name}</div>
          <h3 className="text-sm font-medium text-ink leading-snug line-clamp-2 mb-2 min-h-[2.5em]">
            {product.title}
          </h3>
          <div className="flex items-center justify-between">
            <div className="price-tag pl-2 text-ink">
              <span className="text-base font-semibold">${product.price.toFixed(2)}</span>
              {product.compareAtPrice && (
                <span className="text-xs text-muted line-through">${product.compareAtPrice.toFixed(2)}</span>
              )}
            </div>
            {product.rating > 0 && (
              <div className="flex items-center gap-1 text-xs text-muted">
                <svg className="w-3.5 h-3.5 text-accent fill-current" viewBox="0 0 20 20">
                  <path d="M10 1.5l2.6 5.6 6 .7-4.5 4.1 1.2 6-5.3-3-5.3 3 1.2-6L1.4 7.8l6-.7L10 1.5z" />
                </svg>
                {product.rating.toFixed(1)}
              </div>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}
