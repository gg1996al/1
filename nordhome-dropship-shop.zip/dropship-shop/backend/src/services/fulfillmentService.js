import { prisma } from '../config/db.js';
import { getAdapter } from './supplierAdapter.js';

/**
 * Запускается после подтверждения оплаты заказа. Модель посредничества:
 * магазин сам ничего не отгружает — он передаёт позиции заказа поставщику(-ам)
 * через их адаптер, а дальше поставщик отправляет товар напрямую покупателю.
 * Если в одном заказе товары от разных поставщиков — заказ автоматически "расщепляется"
 * по поставщикам (каждому уходит отдельный вызов placeOrder).
 */
export async function fulfillOrder(orderId) {
  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } });
  if (!order) return;

  const itemsBySupplier = new Map();
  for (const item of order.items) {
    const key = item.supplierId || 'NO_SUPPLIER';
    if (!itemsBySupplier.has(key)) itemsBySupplier.set(key, []);
    itemsBySupplier.get(key).push(item);
  }

  for (const [supplierId, items] of itemsBySupplier) {
    if (supplierId === 'NO_SUPPLIER') continue;
    const supplier = await prisma.supplier.findUnique({ where: { id: supplierId } });
    if (!supplier) continue;

    try {
      const adapter = getAdapter(supplier.type);
      const config = JSON.parse(supplier.configJson || '{}');
      const result = await adapter.placeOrder(config, { ...order, items });

      for (const item of items) {
        await prisma.orderItem.update({
          where: { id: item.id },
          data: {
            fulfillmentStatus: result.ok ? 'SENT' : 'FAILED',
            supplierOrderRef: result.supplierOrderRef,
          },
        });
      }
    } catch (err) {
      for (const item of items) {
        await prisma.orderItem.update({ where: { id: item.id }, data: { fulfillmentStatus: 'FAILED' } });
      }
      console.error(`Ошибка отправки заказа поставщику ${supplier.name}:`, err.message);
    }
  }

  await prisma.order.update({ where: { id: order.id }, data: { status: 'PROCESSING' } });
}
